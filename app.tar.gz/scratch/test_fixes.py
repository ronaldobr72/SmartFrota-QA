import sys
import os
import sqlite3

# Adicionar pasta raiz ao sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import database as db

def test_verificar_conexao():
    print("\n--- Teste 1: verificar_conexao ---")
    db.set_force_offline(False)
    conn_state = db.verificar_conexao()
    print(f"Estado de conexao (online): {conn_state}")
    assert isinstance(conn_state, bool), "verificar_conexao deve retornar booleano"
    
    db.set_force_offline(True)
    offline_state = db.verificar_conexao()
    print(f"Estado de conexao (force_offline): {offline_state}")
    assert offline_state is False, "force_offline deve forcar False"
    db.set_force_offline(False)
    print("PASS: verificar_conexao OK!")

def test_km_calculation():
    print("\n--- Teste 2: get_last_registered_km ---")
    km = db.get_last_registered_km()
    print(f"Ultimo KM registrado (geral): {km}")
    assert km >= 0.0, "KM deve ser positivo"
    print("PASS: get_last_registered_km OK!")

def test_daily_events_fallback():
    print("\n--- Teste 3: get_daily_events e fallback historico ---")
    # Busca do dia de hoje (pode ser vazio)
    events_today = db.get_daily_events(start_date="2099-01-01T00:00:00Z")
    print(f"Eventos em data futura (esperado vazio): {len(events_today)}")
    assert len(events_today) == 0

    # Busca historica geral (deve trazer registros se existirem)
    all_events = db.get_daily_events()
    print(f"Total de eventos no banco local: {len(all_events)}")
    if all_events:
        last_ev = all_events[-1]
        print(f"Ultimo evento historico: {last_ev.get('nome_evento')} (KM: {last_ev.get('km_atual')})")
    print("PASS: get_daily_events fallback OK!")

def test_unsynced_and_database_integrity():
    print("\n--- Teste 4: integridade de dados e contagem ---")
    unsynced = db.get_unsynced_count()
    print(f"Registros locais pendentes de sincronizacao: {unsynced}")
    print("PASS: contagem de pendencias OK!")

if __name__ == "__main__":
    test_verificar_conexao()
    test_km_calculation()
    test_daily_events_fallback()
    test_unsynced_and_database_integrity()
    print("\nTODOS OS TESTES PASSARAM COM SUCESSO!")
