import urllib.request
import os
from dotenv import load_dotenv

load_dotenv()
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://qujyjtavggrfhueizqhz.supabase.co")

try:
    req = urllib.request.Request(SUPABASE_URL, method="GET")
    with urllib.request.urlopen(req, timeout=2.0) as response:
        print("Status code:", response.status)
        print("Data:", response.read().decode())
except Exception as e:
    print("Error details:")
    import traceback
    traceback.print_exc()
