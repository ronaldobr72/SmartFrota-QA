import database as db
try:
    print("Verificando conexão...")
    conn = db.verificar_conexao()
    print("Conexão ativa?", conn)
    
    print("\nBuscando empresas...")
    empresas = db.get_empresas()
    print("Empresas:", empresas)
    
    print("\nBuscando configurações de eventos...")
    # Chamamos get_event_configs sem silenciar a exceção para ver o erro real se houver
    import urllib.request, urllib.parse, json
    params = [("order", "nome.asc")]
    res = db._make_request("GET", "sf_configuracoes_eventos", params=params)
    print("Configurações do banco:", res)
except Exception as e:
    import traceback
    traceback.print_exc()
