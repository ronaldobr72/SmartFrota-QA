#!/bin/bash
# =======================================================
#   SmartFrota - Auto Deploy PWA (PRODUÇÃO) - macOS
#   Equivalente ao deploy.bat do Windows
#
#   Uso:
#     ./deploy.sh          # build + commit + push (force)
# =======================================================
set -euo pipefail

# ---------- Configurações (ajuste se necessário) ----------
# Diretório dos fontes (onde este script está)
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"

# Ambiente virtual com flet 0.23.2 (necessário para o build web)
VENV_BIN="${VENV_BIN:-/Users/ronaldofranciscorosa/smartfrota-build-venv/bin}"
FLET="$VENV_BIN/flet"
PYTHON="$VENV_BIN/python"

# Base URL do GitHub Pages
BASE_URL="/SmartFrota-PRD/"

# Repositório de produção (o build é publicado no branch main)
PROD_REMOTE="https://github.com/ronaldobr72/SmartFrota-PRD.git"
# ----------------------------------------------------------

echo "======================================================="
echo "   SmartFrota - Auto Deploy PWA (PRODUÇÃO)"
echo "======================================================="
echo ""

# Verifica dependências
if [[ ! -x "$FLET" ]]; then
    echo "[ERRO] flet não encontrado em $FLET"
    echo "       Crie o venv: python3 -m venv ~/smartfrota-build-venv"
    echo "       e instale:   ~/smartfrota-build-venv/bin/pip install flet==0.23.2 python-dotenv==1.0.1"
    exit 1
fi

echo "1. Limpando cache local (evita empacotar o banco local)..."
rm -rf "$SOURCE_DIR/local_cache.db" "$SOURCE_DIR/__pycache__"

echo "2. Compilando o aplicativo Flet para Web (Produção)..."
cd "$SOURCE_DIR"
"$FLET" publish main_mobile.py --base-url "$BASE_URL"

echo "3. Aplicando patch de versão do Flet WebAssembly e branding..."
"$PYTHON" patch_worker.py --env prod

echo "3.1 Gerando ícones e imagens SmartFrota (Produção/azul)..."
if ! python3 -c "import PIL" 2>/dev/null; then
    echo "[ERRO] Pillow não encontrado. Instale com: pip3 install pillow"
    exit 1
fi
python3 generate_icons.py --env prod

echo "4. Preparando o repositório do build (dist)..."
DIST_DIR="$SOURCE_DIR/dist"
cd "$DIST_DIR"
if [[ ! -d .git ]]; then
    git init
fi
git remote set-url origin "$PROD_REMOTE" 2>/dev/null || git remote add origin "$PROD_REMOTE"
git branch -M main

echo "5. Commitando e enviando (force para publicar o build)..."
if [[ -n "$(git status --porcelain)" ]]; then
    git add -A
    git -c user.name="ronaldobr72" -c user.email="ronaldobr72@users.noreply.github.com" \
        commit -m "Deploy Flet PWA App - Produção ($(date '+%Y-%m-%d %H:%M:%S'))"
else
    echo "   Nenhuma mudança para commitar."
fi

# HTTP/1.1 + postBuffer maior: evita "RPC failed; HTTP 400" em pushes grandes
git -c http.postBuffer=524288000 -c http.version=HTTP/1.1 push -u origin main --force

echo ""
echo "======================================================="
echo "   Deploy concluído!"
echo "   https://ronaldobr72.github.io/SmartFrota-PRD/"
echo "======================================================="
