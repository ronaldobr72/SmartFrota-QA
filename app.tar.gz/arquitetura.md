# SmartFrota — Documentação de Arquitetura e Engenharia de Software

## 1. Visão Geral do Sistema

O **SmartFrota** é uma solução para gestão de frotas escolares e corporativas, estruturada em modelo **Multi-Tenant** (múltiplas empresas com isolamento de dados), operando em duas frentes complementares:

1. **SmartFrota Mobile (PWA / WebApp)**: Aplicativo voltado ao motorista, executado no navegador do smartphone via **Flet + Pyodide (WebAssembly)**, projetado para operar com **Offline-First**, registro sequencial de paradas/eventos da jornada, rastreamento de quilometragem por odômetro virtual (GPS breadcrumbs) e controle de despesas (combustível, manutenção).
2. **SmartFrota Desktop (Backoffice)**: Painel administrativo desktop em **Flet Nativo (Python)** para gestores da empresa, permitindo controle de veículos, motoristas, visibilidade e ordenação de eventos da rota, relatórios de custos por trechos (baseado em cálculo médio por KM) e módulo de testes/sandbox.
3. **Backend / Banco de Dados**: **Supabase (PostgreSQL)** compartilhado via API REST (PostgREST), com prefixo `sf_` nas tabelas para conviver isoladamente com outros sistemas.

---

## 2. Diagrama de Arquitetura Geral

```mermaid
graph TB
    subgraph "Ambiente Mobile (Motorista - PWA)"
        UI_M["Interface Flet (Flutter Web)"]
        Bridge["GPS Bridge (JS BroadcastChannel)"]
        Worker["Pyodide Web Worker (Python Wasm)"]
        IDBFS[("IndexedDB (IDBFS - SQLite Cache)")]
        UI_M <--> Worker
        Bridge --> Worker
        Worker <--> IDBFS
    end

    subgraph "Ambiente Desktop (Backoffice - Gestor)"
        UI_D["Interface Flet (Desktop Python)"]
        DB_DIRECT["Módulo database.py (DIRECT_SUPABASE = True)"]
        UI_D <--> DB_DIRECT
    end

    subgraph "Backend em Nuvem (Supabase)"
        REST["PostgREST API (/rest/v1)"]
        PG[("PostgreSQL")]
        REST <--> PG
    end

    subgraph "Serviços Externos"
        OSRM["OSRM API (Snap-to-Road Routing)"]
    end

    Worker -.->|"HTTP REST (XHR / Sync)"| REST
    DB_DIRECT -->|"urllib.request / REST"| REST
    Worker -.->|"Cálculo Distância Viária"| OSRM
    DB_DIRECT -.->|"Cálculo Trechos"| OSRM
```

---

## 3. Pilha Tecnológica (Tech Stack)

| Camada | Tecnologia | Detalhes |
|---|---|---|
| **Linguagem Principal** | Python 3.11 / 3.12 / 3.13 | Utilizado em todo o backoffice e na lógica mobile |
| **Framework de Interface** | Flet 0.23.2 | Baseado em Flutter, compilado para Web e Desktop |
| **Runtime WebAssembly** | Pyodide 0.24.1 | Executa o interpretador Python diretamente no Web Worker do navegador |
| **Persistência Local (Browser)** | SQLite via IDBFS (Emscripten) | Arquivo `local_cache.db` espelhado no IndexedDB do navegador |
| **Persistência Local (Desktop)** | SQLite 3 | Arquivo local `local_cache.db` em disco |
| **Backend & Banco de Dados** | Supabase (PostgreSQL 15+) | REST API nativa (PostgREST), com autenticação por chave de API |
| **Roteamento / Distância** | OSRM (Open Source Routing Machine) | API pública de cálculo de rotas reais por malha viária |
| **PWA & Cache** | Service Worker + Manifest | Configuração para instalação em tela inicial e cache de assets |
| **Deploy & Homologação** | GitHub Pages | Branches públicas `SmartFrota-QA` e `SmartFrota-PRD` |

---

## 4. Estrutura de Arquivos e Componentes

```
SmartFrota/
├── database.py              # Camada de abstração de dados (Supabase REST + SQLite local)
├── main_mobile.py           # Aplicação PWA do Motorista (UI, GPS, sincronizador, offline)
├── main_desktop.py          # Aplicação Backoffice Desktop (Gestão, Relatórios, Trechos)
├── schema.sql               # Script DDL de criação do banco de dados no Supabase
├── migration_sandbox.sql    # Script de migração para flag sandbox
├── patch_worker.py          # Pós-processador do build Flet (Pyodide, IDBFS, Service Worker)
├── generate_icons.py        # Gerador de ícones PWA para produção e homologação
├── deploy_homolog.bat / .sh # Scripts de automação de build e deploy para QA (GitHub Pages)
├── deploy.bat / .sh         # Scripts de automação de deploy para PRD (GitHub Pages)
├── especificacao.md         # Documento de especificação funcional e regras de negócio
├── requirements.txt         # Dependências do projeto (flet, python-dotenv)
├── local_cache.db           # Banco de dados SQLite local de testes/cache
├── inspect_db.py            # Utilitário de inspeção do cache local SQLite
├── clear_db.py              # Script utilitário para limpeza de banco (com ressalvas)
└── dist/                    # Saída compilada do Flet Web / PWA pronta para GitHub Pages
```

---

## 5. Modelo de Dados e Relacionamentos

### 5.1. Entidades Principais no Supabase

```mermaid
erDiagram
    sf_empresas ||--o{ sf_usuarios : "possui"
    sf_empresas ||--o{ sf_veiculos : "possui"
    sf_empresas ||--o{ sf_configuracoes_eventos : "define"
    sf_empresas ||--o{ sf_eventos_diarios : "agrega"
    sf_empresas ||--o{ sf_eventos_macros : "agrega"
    
    sf_veiculos ||--o| sf_usuarios : "atribuido a"
    sf_usuarios ||--o{ sf_usuario_configuracoes_eventos : "configurado em"
    sf_configuracoes_eventos ||--o{ sf_usuario_configuracoes_eventos : "vinculado a"
    
    sf_usuarios ||--o{ sf_eventos_diarios : "registra"
    sf_usuarios ||--o{ sf_eventos_macros : "registra"

    sf_empresas {
        uuid id PK
        text nome
        text cnpj
        boolean sandbox
        timestamptz created_at
    }

    sf_veiculos {
        uuid id PK
        uuid empresa_id FK
        text placa
        text marca
        text modelo
        timestamptz created_at
    }

    sf_usuarios {
        uuid id PK
        uuid empresa_id FK
        text nome
        text email
        text role
        text senha
        uuid veiculo_id FK
        timestamptz created_at
    }

    sf_configuracoes_eventos {
        uuid id PK
        uuid empresa_id FK
        text nome
        text tipo
        boolean visivel_motorista
        timestamptz created_at
    }

    sf_usuario_configuracoes_eventos {
        uuid usuario_id PK, FK
        uuid configuracao_evento_id PK, FK
        integer ordem_sequencia
        boolean participa_sequencia
    }

    sf_eventos_diarios {
        uuid id PK
        uuid empresa_id FK
        uuid usuario_id FK
        text nome_evento
        timestamptz data_hora
        numeric km_atual
        numeric latitude
        numeric longitude
        integer seq_ordenacao
        numeric km_breadcrumbs
        numeric km_snap_road
    }

    sf_eventos_macros {
        uuid id PK
        uuid empresa_id FK
        uuid usuario_id FK
        text evento_nome
        timestamptz data_hora
        numeric km_atual
        numeric litros
        numeric valor_por_litro
        text descricao
        numeric valor_total
    }
```

---

## 6. Mecanismo de Funcionamento Offline-First

O SmartFrota Mobile foi projetado com a filosofia **Offline-First**:

1. **Gravação Imediata no SQLite**: Quando o motorista clica em "Registrar Evento da Rota" ou "Registrar Despesa", o registro é salvo com status `sincronizado = 0` no banco SQLite local (`sf_local_diarios` ou `sf_local_macros`). A UI não espera resposta do servidor remoto, eliminando delays na estrada.
2. **Persistência via IDBFS**: No navegador, o sistema de arquivos virtual do Pyodide é volátil por padrão. A função `_sync_fs_to_idb()` invoca `FS.syncfs(false, ...)` para gravar o arquivo SQLite diretamente no IndexedDB do navegador.
3. **Loop de Sincronização em Segundo Plano**: A corrotina `sync_worker_loop()` em `main_mobile.py` roda a cada 10 segundos. Se a conexão estiver disponível:
   - Executa exclusões pendentes (`sf_local_exclusoes_pendentes`).
   - Envia registros pendentes para o Supabase via `POST /rest/v1/sf_eventos_*` com header `Prefer: resolution=merge-duplicates` (idempotência).
   - Atualiza `sincronizado = 1` no SQLite local.
   - Atualiza cache local com novos dados vindos da nuvem (`atualizar_cache_local`).

---

## 7. Diagnóstico: O que pode NÃO estar funcionando (Bugs, Inconsistências e Riscos)

Abaixo está o levantamento minucioso dos pontos falhos encontrados na análise do código-fonte:

### 7.1. Bug Crítico de Interface: Controle Duplicado na Árvore Flet (`status_badge`)
- **Arquivo**: `main_mobile.py` (linhas 1062 e 1386)
- **Problema**: O mesmo objeto `status_badge = ft.Container(...)` é adicionado simultaneamente em dois lugares da árvore de widgets:
  1. Dentro do `AppBar.actions`: `actions=[status_badge, ...]`
  2. Dentro da linha de topo da aba de registro: `ft.Row([status_badge, force_offline_switch, sync_banner], ...)`
- **Impacto**: No Flutter/Flet, um elemento de UI não pode ter dois nós pais (re-parenting conflituoso). Isso gera exceções em tempo de execução ou faz o badge sumir de um dos locais.

---

### 7.2. Bug de Escopo de Variável no Ajuste de KM (`on_km_input_change` e `on_km_macro_input_change`)
- **Arquivo**: `main_mobile.py` (linhas 847-855 e 942-950)
- **Problema**: Ao digitar no campo de KM da jornada ou de despesas:
  ```python
  def on_km_input_change(e):
      nonlocal km_edited
      km_edited = True
      parsed = to_float_safe(km_input.value, default=None)
      if parsed is not None:
          last_km = parsed # <-- FALTA nonlocal last_km!
      persist_progress(force=True)
  ```
- **Impacto**: Como `last_km` não foi declarado com `nonlocal` dentro dessas duas funções aninhadas, o Python cria uma variável local que é descartada imediatamente ao final da função. A variável externa `last_km` **nunca é atualizada pela digitação manual**, e a chamada `persist_progress` logo em seguida grava o valor antigo desatualizado!

---

### 7.3. Sobrecarga e Bloqueio Síncrono no Web Worker do Navegador
- **Arquivo**: `database.py` (`_make_request`) e `main_mobile.py` (`sync_worker_loop`)
- **Problema**:
  1. No Pyodide/browser, `_make_request` utiliza chamada síncrona: `xhr.open(method, url, False)`.
  2. O loop `sync_worker_loop()` roda **a cada 10 segundos**.
  3. A cada ciclo, são feitas até **7 requisições HTTP síncronas sequenciais** (`sf_empresas`, `sf_usuarios`, `sf_configuracoes_eventos`, `sf_veiculos`, `sf_usuario_configuracoes_eventos`, `sf_eventos_diarios`, `sf_eventos_macros`).
- **Impacto**:
  - São mais de 40 requisições por minuto ao Supabase para um único celular.
  - Como a chamada é síncrona no worker, o worker fica travado durante a resposta de rede. Se a rede 4G oscilar ou tiver latência de 500ms, o app congela por 3 a 5 segundos periodicamente.
  - Consumo excessivo de bateria e franquia de dados móveis do motorista.

---

### 7.4. Ausência de Validação de Status HTTP no Navegador (`_make_request`)
- **Arquivo**: `database.py` (linhas 363-382)
- **Problema**: No bloco `emscripten`, `xhr.send()` só lança exceção em falha catastrófica de rede (CORS ou sem rota). Se o Supabase retornar **400 Bad Request**, **401 Unauthorized** ou **409 Conflict**:
  - `xhr.send()` NÃO lança exceção.
  - `xhr.responseText` traz um JSON de erro como `{"code":"...", "message":"..."}`.
  - A função retorna esse dicionário normalmente.
- **Impacto**: Em `sincronizar_dados_pendentes`, o código assume que o retorno foi sucesso, executa `UPDATE sf_local_diarios SET sincronizado = 1` e marca o registro como sincronizado, **perdendo o dado pendente sem que ele tenha sido gravado de fato no Supabase**!

---

### 7.5. Falsa Conexão em Ambiente WebAssembly (`verificar_conexao`)
- **Arquivo**: `database.py` (linhas 265-266)
- **Problema**:
  ```python
  if sys.platform == "emscripten":
      return True
  ```
  Está fixo que na Web a conexão é SEMPRE verdadeira (exceto se a flag manual de teste `FORCE_OFFLINE` estiver ativa).
- **Impacto**: Se o motorista estiver em garagem subterrânea ou área sem sinal, `verificar_conexao()` continua retornando `True`. O sincronizador tenta disparar 7 requisições XHR a cada 10 segundos que falham por timeout/NetworkError, enquanto o status visual no topo da tela exibe incorretamente `"Online"`. O correto no browser é consultar `js.navigator.onLine`.

---

### 7.6. Falha no Boot Inicial Offline do PWA (Cold Launch Offline)
- **Arquivo**: `dist/python-worker.js` (linhas 18 e 25)
- **Problema**:
  1. A instrução `response = await pyfetch("app.tar.gz", cache="no-store")` proíbe expressamente o armazenamento em cache do bundle do código Python.
  2. O `python-worker.js` executa `await micropip.install(deps)` a cada inicialização do worker, consultando o repositório online do PyPI.
- **Impacto**: Se o motorista abrir o PWA pela primeira vez no dia sem internet (ou recarregar a página sem rede), o `pyfetch` com `no-store` e o `micropip` falharão, e o aplicativo sequer iniciará a tela de login.

---

### 7.7. Incompatibilidade com o Service Worker do Flutter
- **Arquivo**: `patch_worker.py` vs `flutter_bootstrap.js`
- **Problema**: O patcher altera `serviceWorkerVersion` em `index.html`. No entanto, em versões recentes do Flutter Web, quem carrega e valida o Service Worker é `flutter_bootstrap.js`, que mantém um valor hash estático. Além disso, o arquivo `flutter_service_worker.js` contém hashes MD5 de integridade dos arquivos (`index.html`, `python-worker.js`), que são alterados pelo `patch_worker.py` após o build sem recalcular esses hashes no manifest do Service Worker.
- **Impacto**: O Service Worker pode rejeitar o novo arquivo por falha de integridade de hash e continuar servindo a versão antiga em cache no celular do usuário.

---

### 7.8. Layout Mobile com Sobreposição e Quebra Visual em Telas Pequenas
- **Arquivo**: `main_mobile.py` (linha 1062)
- **Problema**:
  `ft.Row([status_badge, force_offline_switch, sync_banner], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)`
  Em uma tela de smartphone (360 a 412 pixels de largura), colocar simultaneamente na mesma linha:
  - Um badge com indicador e texto;
  - Um Switch com rótulo "Forçar Offline (teste)";
  - Um banner completo com ícone, texto "X registros pendentes offline" e botão de sincronização;
- **Impacto**: Causa compressão extrema, truncamento de textos e sobreposição de controles clicáveis, violando a regra de ouro de usabilidade mobile.

---

### 7.9. Quebra da Sequência de Eventos na Mudança de Dia / Madrugada
- **Arquivo**: `main_mobile.py` (linhas 365-371 e 1432-1435)
- **Problema**: As funções `load_initial_data()` e `refresh_last_event()` buscam eventos com `start_date=_local_day_start_utc(0)` (apenas do dia atual a partir da meia-noite).
- **Impacto**: Se o motorista abrir o app no primeiro horário da manhã (ou operar em turno noturno que atravessou a meia-noite) e ainda não tiver registrado eventos no dia civil de hoje, `events` vem vazio e `last_daily_event` torna-se `None`. A rotina `get_next_sequential_event()` perde o histórico de onde o motorista havia parado e volta sempre forçadamente para o primeiro evento da lista, quebrando o ciclo contínuo previsto na especificação.

---

### 7.10. Erro Crítico no Script `clear_db.py`
- **Arquivo**: `clear_db.py` (linha 24)
- **Problema**: Chama `client = db.get_supabase_client()`, porém essa função **não existe** em `database.py`.
- **Impacto**: O script aborta imediatamente com `AttributeError: module 'database' has no attribute 'get_supabase_client'`.

---

### 7.11. Coluna `sandbox` Inexistente na Tabela `sf_empresas` no Supabase
- **Arquivo**: Supabase Cloud vs `migration_sandbox.sql`
- **Problema**: A migração `ALTER TABLE public.sf_empresas ADD COLUMN IF NOT EXISTS sandbox BOOLEAN DEFAULT false;` nunca foi executada no banco de dados de produção do Supabase.
- **Impacto**: Tentativas de leitura ou escrita da coluna `sandbox` diretamente via REST no Supabase falhariam ou retornariam `None`.

---

## 8. Plano de Melhorias e Recomendações Técnicas

### 8.1. Correções Imediatas no Aplicativo Mobile (`main_mobile.py`)

1. **Desacoplar o `status_badge`**: Manter o status de conectividade exclusivamente na `AppBar` ou criar instâncias separadas para cada contêiner, eliminando a duplicação de nós.
2. **Corrigir Escopo de `last_km`**: Adicionar `nonlocal last_km` em `on_km_input_change` e `on_km_macro_input_change`.
3. **Organização do Header Mobile**: Mover o `sync_banner` para uma linha própria abaixo da barra superior (como um banner de alerta expansível) e exibir o `force_offline_switch` apenas quando o modo sandbox estiver ativo, em linha dedicada.
4. **Resiliência de Sequência entre Dias**: Em `refresh_last_event()` e `load_initial_data()`, caso a busca de eventos de hoje não retorne registros, buscar o último registro histórico do motorista sem filtro de data para manter o próximo evento da sequência em loop correto.
5. **Checagem Real de Conexão no Navegador**: Substituir `return True` em `database.py` por verificação de `js.navigator.onLine`.

### 8.2. Otimização do Mecanismo de Sincronização e Tráfego de Rede

1. **Sincronização Orientada a Eventos / Backoff Exponencial**:
   - Em vez de consultar 7 endpoints a cada 10 segundos incondicionalmente, executar o pull de configurações apenas no login ou a cada 5 a 10 minutos.
   - O loop de 10s deve apenas verificar se há dados pendentes locais (`sf_local_* WHERE sincronizado = 0`) para envio (push).
2. **Validação de Código HTTP no XHR**:
   - No `_make_request`, inspecionar `xhr.status`. Se `xhr.status < 200` ou `xhr.status >= 300`, lançar exceção contendo a mensagem de erro da resposta para que o sincronizador contabilize a falha e **não** marque o registro como sincronizado indevidamente.

### 8.3. Garantia de Funcionamento Offline Completo do PWA

1. **Remover `cache="no-store"` do `app.tar.gz`**:
   - Utilizar query string de versão (ex: `app.tar.gz?v=<timestamp>`) que garante download da versão mais nova quando online, mas permite que o Service Worker e o cache HTTP sirvam o arquivo quando a rede estiver indisponível.
2. **Pré-empacotar dependências do Python**:
   - Assegurar que as dependências necessárias estejam presentes localmente ou embutidas no build, evitando que o `micropip` precise acessar a internet para abrir a tela do aplicativo.
3. **Atualização dos Hashes do Service Worker**:
   - Ajustar o script `patch_worker.py` para recalcular o hash MD5 dos arquivos modificados dentro de `flutter_service_worker.js`, assegurando que o navegador baixe a versão atualizada de forma limpa e sem conflitos de cache.

---

## 9. Matriz de Conformidade com a Especificação Técnica

| Requisito da Especificação | Status Atual | Diagnóstico / Ajuste Necessário |
|---|---|---|
| Multi-Tenant: Empresa como entidade principal | **Conforme** | Modelagem `sf_empresas` com relacionamento em cascata implementada |
| Veículo vinculado à empresa e atribuído ao motorista | **Conforme** | Coluna `veiculo_id` em `sf_usuarios` e tabela `sf_veiculos` presentes |
| Motorista visualiza apenas seus próprios registros | **Conforme** | Filtros `usuario_id` aplicados nas consultas locais e remotas |
| Sequência de eventos diários ordenada em loop | **Parcial** | Lógica de loop existe, mas reseta indevidamente ao virar o dia civil |
| Odômetro virtual dinâmico com GPS | **Conforme** | Algoritmo Haversine + Breadcrumbs e persistência de progresso operacionais |
| Lançamento de despesas extras associadas à empresa | **Conforme** | Tela e tabelas de eventos macros funcionais com cálculo automático |
| Funcionamento 100% offline sem travamentos | **Parcial** | Banco SQLite local funciona, mas falta suporte a cold launch offline do PWA |
| Ausência de sobreposição visual em tela mobile | **Não Conforme** | Linha superior da aba de registros possui sobreposição em telas pequenas |
| Atualização confiável de novas versões (cache bust) | **Parcial** | Script existe, mas não atualiza o manifest do `flutter_service_worker.js` |
