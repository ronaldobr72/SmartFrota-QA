-- Script de criação do banco de dados para SmartFrota - Multi-Tenant

-- 1. Tabela de Empresas (Tenants)
CREATE TABLE IF NOT EXISTS public.sf_empresas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome TEXT NOT NULL UNIQUE,
    cnpj TEXT UNIQUE,
    sandbox BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 2. Tabela de Perfis de Usuários
CREATE TABLE IF NOT EXISTS public.sf_usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    empresa_id UUID NOT NULL REFERENCES public.sf_empresas(id) ON DELETE CASCADE,
    nome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'gestor', 'motorista')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 3. Tabela de configurações dos eventos (Macros e Diários)
CREATE TABLE IF NOT EXISTS public.sf_configuracoes_eventos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    empresa_id UUID REFERENCES public.sf_empresas(id) ON DELETE CASCADE,
    nome TEXT NOT NULL,
    tipo TEXT NOT NULL CHECK (tipo IN ('macro', 'diario')),
    visivel_motorista BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    UNIQUE(empresa_id, nome)
);

-- 4. Tabela de eventos diários (Jornada)
CREATE TABLE IF NOT EXISTS public.sf_eventos_diarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    empresa_id UUID REFERENCES public.sf_empresas(id) ON DELETE CASCADE,
    usuario_id UUID REFERENCES public.sf_usuarios(id) ON DELETE SET NULL,
    nome_evento TEXT NOT NULL,
    data_hora TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    km_atual NUMERIC NOT NULL,
    latitude NUMERIC,
    longitude NUMERIC,
    seq_ordenacao SERIAL
);

-- 5. Tabela de eventos macros (Administrativo / Custos)
CREATE TABLE IF NOT EXISTS public.sf_eventos_macros (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    empresa_id UUID REFERENCES public.sf_empresas(id) ON DELETE CASCADE,
    usuario_id UUID REFERENCES public.sf_usuarios(id) ON DELETE SET NULL,
    evento_nome TEXT NOT NULL,
    data_hora TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    km_atual NUMERIC,
    litros NUMERIC,
    valor_por_litro NUMERIC,
    descricao TEXT,
    valor_total NUMERIC NOT NULL
);

-- Habilitar RLS ou garantir acesso livre inicialmente para testes
ALTER TABLE public.sf_empresas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_configuracoes_eventos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_eventos_diarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_eventos_macros ENABLE ROW LEVEL SECURITY;

-- Políticas de acesso público para simplificar o desenvolvimento inicial (sem autenticação complexa)
CREATE POLICY "Acesso total público empresas" ON public.sf_empresas FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso total público usuarios" ON public.sf_usuarios FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso total público configuracoes" ON public.sf_configuracoes_eventos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso total público diarios" ON public.sf_eventos_diarios FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso total público macros" ON public.sf_eventos_macros FOR ALL USING (true) WITH CHECK (true);

-- Dados iniciais de teste (Seed)
-- 1. Criar empresa padrão
INSERT INTO public.sf_empresas (id, nome, cnpj) VALUES
('demo-empresa-1', 'Empresa Demo SmartFrota', '12345678000199')
ON CONFLICT DO NOTHING;

-- 2. Criar usuário padrão
INSERT INTO public.sf_usuarios (id, empresa_id, nome, email, role) VALUES
('demo-usuario-1', 'demo-empresa-1', 'Motorista Demo', 'motorista@demo.com', 'motorista')
ON CONFLICT DO NOTHING;

-- 3. Criar configurações padrões para a empresa padrão
INSERT INTO public.sf_configuracoes_eventos (empresa_id, nome, tipo, visivel_motorista) VALUES
('demo-empresa-1', 'Abastecimento', 'macro', true),
('demo-empresa-1', 'Manutenções', 'macro', true),
('demo-empresa-1', 'Aluguel da garagem', 'macro', false),
('demo-empresa-1', 'Outros', 'macro', true)
ON CONFLICT (empresa_id, nome) DO UPDATE SET
    tipo = EXCLUDED.tipo,
    visivel_motorista = EXCLUDED.visivel_motorista;
