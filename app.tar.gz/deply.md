# Deploy do SmartFrota PWA

Agora a estrutura do projeto foi organizada com governança para evitar o vazamento de informações sensíveis em repositórios públicos:

1. **SmartFrota** (Privado): Contém o código-fonte do projeto.
2. **SmartFrota-QA** (Público): Deploy para testes de qualidade (Homologação).
3. **SmartFrota-PRD** (Público): Deploy de produção.

Os scripts de deploy automatizam todo o processo de publicação compilando o Flet e gerando o build na pasta `dist/`.

---

## Como Fazer o Deploy

### 1. Deploy para Qualidade (QA / Homologação)
Este deploy publica a aplicação em `https://ronaldobr72.github.io/SmartFrota-QA/`.

*   **No Windows:**
    ```cmd
    .\deploy_homolog.bat
    ```
*   **No macOS / Linux:**
    ```bash
    chmod +x deploy_homolog.sh
    ./deploy_homolog.sh
    ```

### 2. Deploy para Produção (PRD)
Este deploy publica a aplicação em `https://ronaldobr72.github.io/SmartFrota-PRD/`.

*   **No Windows:**
    ```cmd
    .\deploy.bat
    ```
*   **No macOS / Linux:**
    ```bash
    chmod +x deploy.sh
    ./deploy.sh
    ```
