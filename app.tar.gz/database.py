import os
import sys
import sqlite3
import json
import urllib.request
import urllib.parse
import time
from datetime import datetime, timezone
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Configurações padrão do Supabase
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://qujyjtavggrfhueizqhz.supabase.co")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "sb_publishable_7T52Xr1pyP1hPzC5q815Tw_MH7NrpIC")

BASE_DIR = os.path.dirname(__file__)
if sys.platform == "emscripten":
    # No navegador (Pyodide), o banco local fica em diretório persistido via IDBFS (IndexedDB)
    SQLITE_PATH = "/home/pyodide/persist/local_cache.db"
else:
    SQLITE_PATH = os.path.join(BASE_DIR, "local_cache.db")
DIRECT_SUPABASE = False
FORCE_OFFLINE = False
SANDBOX_EMPRESA_IDS = set()

_FS_SYNC_IN_PROGRESS = False
_FS_SYNC_DIRTY = False
_LAST_PROGRESS_SYNCFS = 0.0


def _sync_fs_to_idb():
    """Persiste o SQLite no IndexedDB (somente no navegador/Pyodide).

    Sem esta chamada, os dados gravados no banco local seriam perdidos ao
    fechar o app (o filesystem do Pyodide é volátil em memória).
    """
    global _FS_SYNC_IN_PROGRESS, _FS_SYNC_DIRTY
    if sys.platform != "emscripten":
        return
    if _FS_SYNC_IN_PROGRESS:
        # Marca como "sujo" para garantir que os dados mais recentes sejam
        # persistidos assim que o syncfs em andamento terminar.
        _FS_SYNC_DIRTY = True
        return
    _FS_SYNC_IN_PROGRESS = True
    try:
        from pyodide.ffi import create_proxy
        def _cb(err):
            global _FS_SYNC_IN_PROGRESS, _FS_SYNC_DIRTY
            _FS_SYNC_IN_PROGRESS = False
            if _FS_SYNC_DIRTY:
                _sync_fs_to_idb()
        fs = None
        try:
            import js
            if hasattr(js, "self") and hasattr(js.self, "pyodide") and hasattr(js.self.pyodide, "FS"):
                fs = js.self.pyodide.FS
            elif hasattr(js, "pyodide") and hasattr(js.pyodide, "FS"):
                fs = js.pyodide.FS
            elif hasattr(js, "FS"):
                fs = js.FS
        except Exception:
            pass

        if fs and hasattr(fs, "syncfs"):
            fs.syncfs(False, create_proxy(_cb))
        else:
            _FS_SYNC_IN_PROGRESS = False
    except Exception as e:
        _FS_SYNC_IN_PROGRESS = False

# --- INICIALIZAÇÃO DO SQLITE LOCAL ---
def init_local_db():
    os.makedirs(os.path.dirname(SQLITE_PATH), exist_ok=True)
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    
    # Tabela espelho local para eventos diários
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_diarios (
        id TEXT PRIMARY KEY,
        nome_evento TEXT NOT NULL,
        data_hora TEXT NOT NULL,
        km_atual REAL NOT NULL,
        latitude REAL,
        longitude REAL,
        empresa_id TEXT,
        usuario_id TEXT,
        sincronizado INTEGER DEFAULT 0,
        km_breadcrumbs REAL,
        km_snap_road REAL
    )
    """)
    
    # Tabela espelho local para eventos macros
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_macros (
        id TEXT PRIMARY KEY,
        evento_nome TEXT NOT NULL,
        data_hora TEXT NOT NULL,
        km_atual REAL,
        litros REAL,
        valor_por_litro REAL,
        descricao TEXT,
        valor_total REAL NOT NULL,
        empresa_id TEXT,
        usuario_id TEXT,
        sincronizado INTEGER DEFAULT 0
    )
    """)

    # Tabela cache local de empresas
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_empresas (
        id TEXT PRIMARY KEY,
        nome TEXT NOT NULL,
        cnpj TEXT,
        sandbox INTEGER DEFAULT 0
    )
    """)

    # Tabela cache local de usuários
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_usuarios (
        id TEXT PRIMARY KEY,
        empresa_id TEXT NOT NULL,
        nome TEXT NOT NULL,
        email TEXT NOT NULL,
        role TEXT NOT NULL,
        senha TEXT,
        veiculo_id TEXT
    )
    """)

    # Tabela cache local de configurações de eventos
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_configuracoes_eventos (
        id TEXT PRIMARY KEY,
        empresa_id TEXT,
        nome TEXT NOT NULL,
        tipo TEXT NOT NULL,
        visivel_motorista INTEGER DEFAULT 1
    )
    """)

    # Tabela cache local de veículos
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_veiculos (
        id TEXT PRIMARY KEY,
        empresa_id TEXT NOT NULL,
        placa TEXT NOT NULL UNIQUE,
        marca TEXT,
        modelo TEXT
    )
    """)

    # Tabela para marcar empresas sandbox localmente
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_sandbox (
        empresa_id TEXT PRIMARY KEY
    )
    """)

    # Tabela de progresso da jornada do motorista (recuperação pós-fechamento/travamento)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_progresso (
        usuario_id TEXT PRIMARY KEY,
        km_breadcrumbs REAL DEFAULT 0,
        last_lat REAL,
        last_lon REAL,
        km_atual REAL,
        km_edited INTEGER DEFAULT 0,
        km_macro_edited INTEGER DEFAULT 0,
        updated_at TEXT
    )
    """)

    # Tabela cache local de configurações de eventos por motorista
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_usuario_configuracoes_eventos (
        usuario_id TEXT NOT NULL,
        configuracao_evento_id TEXT NOT NULL,
        ordem_sequencia INTEGER NOT NULL DEFAULT 0,
        participa_sequencia INTEGER DEFAULT 1,
        PRIMARY KEY (usuario_id, configuracao_evento_id)
    )
    """)

    # Tabela de fila de exclusões pendentes offline
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sf_local_exclusoes_pendentes (
        id TEXT PRIMARY KEY,
        tabela TEXT NOT NULL,
        data_hora TEXT NOT NULL
    )
    """)
    
    # Adicionar colunas caso já existam tabelas antigas sem elas
    for table in ["sf_local_diarios", "sf_local_macros"]:
        for col in ["empresa_id", "usuario_id"]:
            try:
                cursor.execute(f"ALTER TABLE {table} ADD COLUMN {col} TEXT")
            except sqlite3.OperationalError:
                pass
                
    for col in ["km_breadcrumbs", "km_snap_road"]:
        try:
            cursor.execute(f"ALTER TABLE sf_local_diarios ADD COLUMN {col} REAL")
        except sqlite3.OperationalError:
            pass

    try:
        cursor.execute("ALTER TABLE sf_local_usuarios ADD COLUMN veiculo_id TEXT")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE sf_local_usuario_configuracoes_eventos ADD COLUMN participa_sequencia INTEGER DEFAULT 1")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE sf_local_empresas ADD COLUMN sandbox INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass
    
    conn.commit()
    conn.close()

# Inicializa o banco local ao carregar o módulo
init_local_db()

# Carrega IDs de empresas sandbox salvos localmente (persistência)
def _load_sandbox_empresa_ids_from_db():
    global SANDBOX_EMPRESA_IDS
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT empresa_id FROM sf_local_sandbox")
        rows = cursor.fetchall()
        conn.close()
        SANDBOX_EMPRESA_IDS = set([r[0] for r in rows if r and r[0]])
    except Exception:
        SANDBOX_EMPRESA_IDS = set()

# Persistência: grava os ids em memória para o banco local
def _persist_sandbox_empresa_ids_to_db():
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM sf_local_sandbox")
        for eid in SANDBOX_EMPRESA_IDS:
            cursor.execute("INSERT OR REPLACE INTO sf_local_sandbox (empresa_id) VALUES (?)", (eid,))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Erro ao persistir sandbox ids: {e}")
    else:
        # debug trace to help diagnose lost flag across processes
        try:
            print(f"[SANDBOX] persisted ids -> {sorted(list(SANDBOX_EMPRESA_IDS))}")
        except Exception:
            pass

# --- VERIFICAÇÃO DE CONEXÃO ---
def verificar_conexao() -> bool:
    import sys
    global FORCE_OFFLINE
    if FORCE_OFFLINE:
        return False
    if sys.platform == "emscripten":
        try:
            import js
            if hasattr(js, "navigator") and hasattr(js.navigator, "onLine"):
                if not js.navigator.onLine:
                    return False
        except Exception:
            pass
        return True
    try:
        # Faz uma chamada simples para o Supabase
        import urllib.error
        req = urllib.request.Request(SUPABASE_URL, method="GET")
        with urllib.request.urlopen(req, timeout=2.0) as response:
            return True
    except urllib.error.HTTPError:
        # Se retornou código HTTP (mesmo erro como 404 ou 401), a conexão com o servidor está ativa
        return True
    except Exception:
        return False

def set_force_offline(flag: bool):
    """Força o modo offline para testes (retorna False em verificar_conexao)."""
    global FORCE_OFFLINE
    FORCE_OFFLINE = bool(flag)

def set_sandbox_empresa_ids(ids):
    """Define empresas em modo sandbox. Recebe lista de ids ou string CSV."""
    global SANDBOX_EMPRESA_IDS
    if ids is None:
        SANDBOX_EMPRESA_IDS = set()
    elif isinstance(ids, str):
        SANDBOX_EMPRESA_IDS = set([x.strip() for x in ids.split(",") if x.strip()])
    elif isinstance(ids, (list, tuple, set)):
        SANDBOX_EMPRESA_IDS = set([str(x).strip() for x in ids if str(x).strip()])
    _persist_sandbox_empresa_ids_to_db()


# Função para marcar/desmarcar uma empresa individualmente
def set_sandbox_empresa(empresa_id: str, flag: bool):
    """Adiciona ou remove uma empresa do modo sandbox."""
    global SANDBOX_EMPRESA_IDS
    if not empresa_id:
        return
    eid = str(empresa_id).strip()
    if flag:
        SANDBOX_EMPRESA_IDS.add(eid)
    else:
        SANDBOX_EMPRESA_IDS.discard(eid)
    _persist_sandbox_empresa_ids_to_db()

    # Propaga a flag para o Supabase (coluna sandbox em sf_empresas).
    # Se a coluna ainda não existir, a chamada falha silenciosamente.
    try:
        _make_request("PATCH", "sf_empresas", params=[("id", f"eq.{empresa_id}")], body={"sandbox": bool(flag)})
    except Exception as e:
        print(f"Não foi possível atualizar sandbox no Supabase (coluna pode não existir): {e}")


def is_empresa_sandbox(empresa_id: str) -> bool:
    """Verifica se a empresa está marcada como sandbox.

    Verifica o set local em memória (persistido no SQLite), a coluna
    'sandbox' da tabela sf_local_empresas e, como fallback, o nome.
    """
    if not empresa_id:
        return False
    eid = str(empresa_id).strip()
    if eid in SANDBOX_EMPRESA_IDS:
        return True
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT sandbox, nome FROM sf_local_empresas WHERE id = ?", (eid,))
        row = cursor.fetchone()
        conn.close()
        if row:
            if row[0]:
                return True
            nome = (row[1] or "").strip().lower()
            if nome == "sandbox":
                return True
    except Exception:
        pass
    return False


# Carrega inicialmente os IDs de empresas sandbox salvos no banco local
_load_sandbox_empresa_ids_from_db()


# --- CLIENTE REST SUPABASE (SEM DEPENDÊNCIA DO SUPABASE-PY) ---
def _make_request(method: str, table: str, params=None, body: dict = None, headers: dict = None) -> list:
    import sys
    url = f"{SUPABASE_URL}/rest/v1/{table}"
    if params:
        query_string = urllib.parse.urlencode(params)
        url += f"?{query_string}"
        
    # Caminho específico para ambiente WebAssembly (Pyodide / Navegador)
    if sys.platform == "emscripten":
        try:
            import js
            xhr = js.XMLHttpRequest.new()
            xhr.open(method, url, False)  # Chamada síncrona dentro do Web Worker
            
            xhr.setRequestHeader("apikey", SUPABASE_KEY)
            xhr.setRequestHeader("Authorization", f"Bearer {SUPABASE_KEY}")
            xhr.setRequestHeader("Content-Type", "application/json")
            if headers:
                for k, v in headers.items():
                    xhr.setRequestHeader(k, v)
                    
            if body is not None:
                xhr.send(json.dumps(body))
            else:
                xhr.send()
                
            status = int(xhr.status)
            res_data = xhr.responseText
            if status < 200 or status >= 300:
                raise RuntimeError(f"HTTP {status} ({method} {table}): {res_data}")

            return json.loads(res_data) if res_data else []
        except Exception as e:
            print(f"Erro XMLHttpRequest no navegador ({method} {table}): {e}")
            raise e

    # Caminho para ambiente Python nativo (Desktop / Mobile Nativo)
    req_headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json"
    }
    if headers:
        req_headers.update(headers)
        
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        
    req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=5.0) as response:
            res_data = response.read().decode("utf-8")
            return json.loads(res_data) if res_data else []
    except Exception as e:
        # Try to surface HTTP error body for diagnostics
        try:
            import urllib.error as urllib_error
            if isinstance(e, urllib_error.HTTPError):
                try:
                    err_body = e.read().decode('utf-8', errors='ignore')
                except Exception:
                    err_body = '<no body>'
                debug_env = os.getenv('DEBUG_SYNC', '0') in ('1', 'true', 'True')
                if debug_env:
                    try:
                        print(f"[DEBUG_SYNC] Request body ({method} {table}): {json.dumps(body)}")
                    except Exception:
                        print(f"[DEBUG_SYNC] Request body not serializable: {body}")
                    print(f"[DEBUG_SYNC] HTTPError {getattr(e, 'code', 'N/A')} response: {err_body}")
                else:
                    print(f"Erro na requisição REST Supabase nativa ({method} {table}): {e}")
                raise e
        except Exception:
            pass
        print(f"Erro na requisição REST Supabase nativa ({method} {table}): {e}")
        raise e

# --- CONFIGURAÇÕES DE EVENTOS ---
def get_event_configs(empresa_id: str = None):
    if DIRECT_SUPABASE:
        try:
            if empresa_id:
                return _make_request("GET", "sf_configuracoes_eventos", params=[("empresa_id", f"eq.{empresa_id}")])
            return _make_request("GET", "sf_configuracoes_eventos")
        except Exception as e:
            print(f"Erro ao obter configs do Supabase diretamente: {e}")
            return []
    # Tenta ler do SQLite primeiro
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        if empresa_id:
            cursor.execute("SELECT id, nome, tipo, visivel_motorista, empresa_id FROM sf_local_configuracoes_eventos WHERE empresa_id = ? ORDER BY nome ASC", (empresa_id,))
        else:
            cursor.execute("SELECT id, nome, tipo, visivel_motorista, empresa_id FROM sf_local_configuracoes_eventos ORDER BY nome ASC")
        rows = cursor.fetchall()
        conn.close()
        if rows:
            res = []
            for r in rows:
                d = dict(r)
                d["visivel_motorista"] = bool(d["visivel_motorista"])
                res.append(d)
            return res
    except Exception as e:
        print(f"Erro ao obter configs locais: {e}")

    # Fallback caso offline e sem registros no banco local
    return [
        {"id": "abast", "nome": "Abastecimento", "tipo": "macro", "visivel_motorista": True, "empresa_id": empresa_id},
        {"id": "manut", "nome": "Manutenções", "tipo": "macro", "visivel_motorista": True, "empresa_id": empresa_id},
        {"id": "aluguel", "nome": "Aluguel da garagem", "tipo": "macro", "visivel_motorista": False, "empresa_id": empresa_id},
        {"id": "outros", "nome": "Outros", "tipo": "macro", "visivel_motorista": True, "empresa_id": empresa_id}
    ]

def update_event_config_visibility(config_id: str, visible: bool):
    if DIRECT_SUPABASE:
        try:
            if verificar_conexao():
                return _make_request("PATCH", "sf_configuracoes_eventos", params=[("id", f"eq.{config_id}")], body={"visivel_motorista": visible})
        except Exception as e:
            print(f"Erro ao atualizar visibilidade no Supabase: {e}")
        return []
    try:
        # Atualiza localmente
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute("UPDATE sf_local_configuracoes_eventos SET visivel_motorista = ? WHERE id = ?", (1 if visible else 0, config_id))
        conn.commit()
        conn.close()
        
        # Se online, envia pro Supabase
        if verificar_conexao():
            return _make_request("PATCH", "sf_configuracoes_eventos", params=[("id", f"eq.{config_id}")], body={"visivel_motorista": visible})
    except Exception:
        pass
    return []

def add_event_config(nome: str, tipo: str, visivel_motorista: bool = True, empresa_id: str = None):
    if DIRECT_SUPABASE:
        try:
            if verificar_conexao():
                import uuid
                config_id = str(uuid.uuid4())
                return _make_request(
                    "POST", 
                    "sf_configuracoes_eventos", 
                    body={"id": config_id, "nome": nome, "tipo": tipo, "visivel_motorista": visivel_motorista, "empresa_id": empresa_id},
                    headers={"Prefer": "return=representation"}
                )
        except Exception as e:
            print(f"Erro ao adicionar config no Supabase: {e}")
        return []
    import uuid
    config_id = str(uuid.uuid4())
    try:
        # Insere localmente
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO sf_local_configuracoes_eventos (id, empresa_id, nome, tipo, visivel_motorista) VALUES (?, ?, ?, ?, ?)",
            (config_id, empresa_id, nome, tipo, 1 if visivel_motorista else 0)
        )
        conn.commit()
        conn.close()

        # Se online, tenta enviar pro Supabase
        if verificar_conexao():
            return _make_request(
                "POST", 
                "sf_configuracoes_eventos", 
                body={"id": config_id, "nome": nome, "tipo": tipo, "visivel_motorista": visivel_motorista, "empresa_id": empresa_id},
                headers={"Prefer": "return=representation"}
            )
    except Exception as e:
        print(f"Erro ao adicionar config de evento: {e}")
    return []

# --- EVENTOS DIÁRIOS ---
def get_daily_events(start_date: str = None, end_date: str = None, empresa_id: str = None, usuario_id: str = None):
    if DIRECT_SUPABASE:
        try:
            params = []
            if start_date: params.append(("data_hora", f"gte.{start_date}"))
            if end_date: params.append(("data_hora", f"lte.{end_date}"))
            if empresa_id: params.append(("empresa_id", f"eq.{empresa_id}"))
            if usuario_id: params.append(("usuario_id", f"eq.{usuario_id}"))
            params.append(("order", "data_hora.asc"))
            return _make_request("GET", "sf_eventos_diarios", params=params)
        except Exception as e:
            print(f"Erro ao obter diarios do Supabase diretamente: {e}")
            return []
    # O motorista lê exclusivamente do banco SQLite local para evitar lags e garantir
    # que veja eventos não sincronizados ainda.
    conn = sqlite3.connect(SQLITE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    query = "SELECT id, nome_evento, data_hora, km_atual, latitude, longitude, empresa_id, usuario_id, sincronizado, km_breadcrumbs, km_snap_road FROM sf_local_diarios"
    conditions = []
    sql_params = []
    
    if start_date:
        conditions.append("data_hora >= ?")
        sql_params.append(start_date)
    if end_date:
        conditions.append("data_hora <= ?")
        sql_params.append(end_date)
    if empresa_id:
        conditions.append("empresa_id = ?")
        sql_params.append(empresa_id)
    if usuario_id:
        conditions.append("usuario_id = ?")
        sql_params.append(usuario_id)
        
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
        
    query += " ORDER BY data_hora ASC"
    cursor.execute(query, sql_params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def register_daily_event(nome_evento: str, km_atual: float, latitude: float = None, longitude: float = None, empresa_id: str = None, usuario_id: str = None, data_hora: str = None, km_breadcrumbs: float = 0.0, km_snap_road: float = 0.0):
    if DIRECT_SUPABASE:
        try:
            if verificar_conexao():
                import uuid
                event_id = str(uuid.uuid4())
                dt = data_hora or datetime.now(timezone.utc).isoformat()
                _make_request("POST", "sf_eventos_diarios", body={
                    "id": event_id,
                    "nome_evento": nome_evento,
                    "data_hora": dt,
                    "km_atual": km_atual,
                    "latitude": latitude,
                    "longitude": longitude,
                    "empresa_id": empresa_id,
                    "usuario_id": usuario_id,
                    "km_breadcrumbs": km_breadcrumbs,
                    "km_snap_road": km_snap_road
                })
                return {"id": event_id, "nome_evento": nome_evento}
        except Exception as e:
            print(f"Erro ao registrar diario no Supabase diretamente: {e}")
        return None
    import uuid
    event_id = str(uuid.uuid4())
    if not data_hora:
        data_hora = datetime.now(timezone.utc).isoformat()

    # Salva EXCLUSIVAMENTE localmente primeiro (Offline-First).
    # Sem chamada síncrona/bloqueante de rede para garantir responsividade total da UI.
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO sf_local_diarios (id, nome_evento, data_hora, km_atual, latitude, longitude, empresa_id, usuario_id, sincronizado, km_breadcrumbs, km_snap_road) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)",
        (event_id, nome_evento, data_hora, km_atual, latitude, longitude, empresa_id, usuario_id, km_breadcrumbs, km_snap_road)
    )
    conn.commit()
    conn.close()
    _sync_fs_to_idb()

    return {"id": event_id, "nome_evento": nome_evento}


# --- EVENTOS MACROS ---
def get_macro_events(start_date: str = None, end_date: str = None, empresa_id: str = None):
    if DIRECT_SUPABASE:
        try:
            params = []
            if start_date: params.append(("data_hora", f"gte.{start_date}"))
            if end_date: params.append(("data_hora", f"lte.{end_date}"))
            if empresa_id: params.append(("empresa_id", f"eq.{empresa_id}"))
            params.append(("order", "data_hora.asc"))
            return _make_request("GET", "sf_eventos_macros", params=params)
        except Exception as e:
            print(f"Erro ao obter macros do Supabase diretamente: {e}")
            return []
    # Leitura local imediata e confiável
    conn = sqlite3.connect(SQLITE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    query = "SELECT id, evento_nome, data_hora, km_atual, litros, valor_por_litro, descricao, valor_total, empresa_id, usuario_id, sincronizado FROM sf_local_macros"
    conditions = []
    params = []
    
    if start_date:
        conditions.append("data_hora >= ?")
        params.append(start_date)
    if end_date:
        conditions.append("data_hora <= ?")
        params.append(end_date)
    if empresa_id:
        conditions.append("empresa_id = ?")
        params.append(empresa_id)
        
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
        
    query += " ORDER BY data_hora ASC"
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def register_macro_event(evento_nome: str, km_atual: float = None, litros: float = None, valor_por_litro: float = None, descricao: str = None, valor_total: float = None, empresa_id: str = None, usuario_id: str = None, data_hora: str = None):
    if DIRECT_SUPABASE:
        try:
            if verificar_conexao():
                import uuid
                event_id = str(uuid.uuid4())
                dt = data_hora or datetime.now(timezone.utc).isoformat()
                if valor_total is None:
                    if litros is not None and valor_por_litro is not None:
                        valor_total = float(litros) * float(valor_por_litro)
                    else:
                        valor_total = 0.0
                _make_request("POST", "sf_eventos_macros", body={
                    "id": event_id,
                    "evento_nome": evento_nome,
                    "data_hora": dt,
                    "km_atual": km_atual,
                    "litros": litros,
                    "valor_por_litro": valor_por_litro,
                    "descricao": descricao,
                    "valor_total": valor_total,
                    "empresa_id": empresa_id,
                    "usuario_id": usuario_id
                })
                return {"id": event_id, "evento_nome": evento_nome}
        except Exception as e:
            print(f"Erro ao registrar macro no Supabase diretamente: {e}")
        return None
    import uuid
    event_id = str(uuid.uuid4())
    if not data_hora:
        data_hora = datetime.now(timezone.utc).isoformat()

    if valor_total is None:
        if litros is not None and valor_por_litro is not None:
            valor_total = float(litros) * float(valor_por_litro)
        else:
            valor_total = 0.0

    # Salva EXCLUSIVAMENTE localmente primeiro (Offline-First).
    # Sem chamada síncrona/bloqueante de rede para garantir responsividade total da UI.
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO sf_local_macros (id, evento_nome, data_hora, km_atual, litros, valor_por_litro, descricao, valor_total, empresa_id, usuario_id, sincronizado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)",
        (event_id, evento_nome, data_hora, km_atual, litros, valor_por_litro, descricao, valor_total, empresa_id, usuario_id)
    )
    conn.commit()
    conn.close()
    _sync_fs_to_idb()

    return {"id": event_id, "evento_nome": evento_nome}

def get_last_registered_km(empresa_id: str = None, usuario_id: str = None) -> float:
    if DIRECT_SUPABASE:
        try:
            params_d = [("order", "data_hora.desc"), ("limit", "1")]
            if empresa_id: params_d.append(("empresa_id", f"eq.{empresa_id}"))
            if usuario_id: params_d.append(("usuario_id", f"eq.{usuario_id}"))
            
            params_m = [("order", "data_hora.desc"), ("limit", "1"), ("km_atual", "not.is.null")]
            if empresa_id: params_m.append(("empresa_id", f"eq.{empresa_id}"))
            if usuario_id: params_m.append(("usuario_id", f"eq.{usuario_id}"))
            
            rows_diario = _make_request("GET", "sf_eventos_diarios", params=params_d)
            rows_macro = _make_request("GET", "sf_eventos_macros", params=params_m)
            
            t_d = rows_diario[0].get("data_hora", "") if rows_diario else ""
            km_d = float(rows_diario[0]["km_atual"]) if rows_diario and rows_diario[0].get("km_atual") is not None else 0.0
            
            t_m = rows_macro[0].get("data_hora", "") if rows_macro else ""
            km_m = float(rows_macro[0]["km_atual"]) if rows_macro and rows_macro[0].get("km_atual") is not None else 0.0
            
            if t_d and t_m:
                return km_d if t_d >= t_m else km_m
            elif t_d:
                return km_d
            elif t_m:
                return km_m
            return 0.0
        except Exception as e:
            print(f"Erro ao obter km do Supabase: {e}")
            return 0.0
    def _parse_iso(dt_str: str) -> datetime:
        if not dt_str:
            return datetime.min
        dt_str = dt_str.replace("Z", "+00:00")
        try:
            dt = datetime.fromisoformat(dt_str)
            # Normalize to timezone-aware UTC for safe comparisons
            if dt.tzinfo is None:
                return dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        except Exception:
            try:
                clean_str = dt_str.split(".")[0].split("+")[0].split("-")[0]
                if "T" in clean_str:
                    dt = datetime.strptime(clean_str, "%Y-%m-%dT%H:%M:%S")
                    return dt.replace(tzinfo=timezone.utc)
                dt = datetime.strptime(clean_str, "%Y-%m-%d %H:%M:%S")
                return dt.replace(tzinfo=timezone.utc)
            except Exception:
                return datetime.min.replace(tzinfo=timezone.utc)

    # Busca no banco SQLite local direto para evitar requisições na Thread principal
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        
        conds_d = []
        p_d = []
        if empresa_id:
            conds_d.append("empresa_id = ?")
            p_d.append(empresa_id)
        if usuario_id:
            conds_d.append("usuario_id = ?")
            p_d.append(usuario_id)
            
        q_d = "SELECT km_atual, data_hora FROM sf_local_diarios"
        if conds_d:
            q_d += " WHERE " + " AND ".join(conds_d)
        q_d += " ORDER BY data_hora DESC LIMIT 1"
        cursor.execute(q_d, p_d)
        row_diario = cursor.fetchone()
        
        conds_m = ["km_atual IS NOT NULL"]
        p_m = []
        if empresa_id:
            conds_m.append("empresa_id = ?")
            p_m.append(empresa_id)
        if usuario_id:
            conds_m.append("usuario_id = ?")
            p_m.append(usuario_id)
            
        q_m = "SELECT km_atual, data_hora FROM sf_local_macros"
        if conds_m:
            q_m += " WHERE " + " AND ".join(conds_m)
        q_m += " ORDER BY data_hora DESC LIMIT 1"
        cursor.execute(q_m, p_m)
        row_macro = cursor.fetchone()
        
        conn.close()
        
        t_diario = datetime.min.replace(tzinfo=timezone.utc)
        km_diario = 0.0
        if row_diario and row_diario[0] is not None:
            km_diario = float(row_diario[0])
            t_diario = _parse_iso(row_diario[1])
            
        t_macro = datetime.min.replace(tzinfo=timezone.utc)
        km_macro = 0.0
        if row_macro and row_macro[0] is not None:
            km_macro = float(row_macro[0])
            t_macro = _parse_iso(row_macro[1])
            
        if t_diario != datetime.min or t_macro != datetime.min:
            return km_diario if t_diario > t_macro else km_macro
    except Exception as e:
        print(f"Erro ao obter km local: {e}")
        
    return 0.0


# --- PROGRESSO DA JORNADA (recuperação pós-fechamento/travamento do app) ---
def save_driver_progress(usuario_id: str, km_breadcrumbs: float = 0.0, last_lat: float = None, last_lon: float = None, km_atual: float = None, km_edited: int = 0, km_macro_edited: int = 0, force_sync: bool = False):
    """Persiste o progresso da jornada (trilha de pão e flags de edição de KM).

    Grava sempre no SQLite local. No navegador (Pyodide), o syncfs para o
    IndexedDB é feito com throttle (~10s) para não sobrecarregar; em edições
    manuais (force_sync=True) a persistência é imediata.
    """
    global _LAST_PROGRESS_SYNCFS
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT OR REPLACE INTO sf_local_progresso
            (usuario_id, km_breadcrumbs, last_lat, last_lon, km_atual, km_edited, km_macro_edited, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (usuario_id, km_breadcrumbs, last_lat, last_lon, km_atual, km_edited, km_macro_edited, datetime.now(timezone.utc).isoformat())
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Erro ao salvar progresso do motorista: {e}")
        return

    # Persistência física no navegador (IDBFS/IndexedDB)
    if force_sync:
        _sync_fs_to_idb()
    else:
        now = time.time()
        if now - _LAST_PROGRESS_SYNCFS > 10.0:
            _LAST_PROGRESS_SYNCFS = now
            _sync_fs_to_idb()


def get_driver_progress(usuario_id: str):
    """Retorna o progresso salvo da jornada do motorista (ou None)."""
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(
            "SELECT usuario_id, km_breadcrumbs, last_lat, last_lon, km_atual, km_edited, km_macro_edited, updated_at FROM sf_local_progresso WHERE usuario_id = ?",
            (usuario_id,)
        )
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    except Exception as e:
        print(f"Erro ao obter progresso do motorista: {e}")
        return None


# --- PROCESSAMENTO DE FILA OFFLINE ---
def get_unsynced_count() -> int:
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM sf_local_diarios WHERE sincronizado = 0")
        diarios = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM sf_local_macros WHERE sincronizado = 0")
        macros = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM sf_local_exclusoes_pendentes")
        exclusoes = cursor.fetchone()[0]
        
        conn.close()
        return diarios + macros + exclusoes
    except Exception:
        return 0

def sincronizar_dados_pendentes() -> tuple[int, int]:
    """Retorna (sincronizados_com_sucesso, falhas)"""
    if not verificar_conexao():
        return 0, 0
        
    conn = sqlite3.connect(SQLITE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    sincronizados = 0
    falhas = 0

    # 0. Sincronizar exclusões pendentes primeiro
    cursor.execute("SELECT * FROM sf_local_exclusoes_pendentes")
    exclusoes_pendentes = cursor.fetchall()
    for row in exclusoes_pendentes:
        try:
            _make_request("DELETE", row["tabela"], params=[("id", f"eq.{row['id']}")])
            cursor2 = conn.cursor()
            cursor2.execute("DELETE FROM sf_local_exclusoes_pendentes WHERE id = ?", (row["id"],))
            sincronizados += 1
        except Exception as ex:
            print(f"Erro ao sincronizar exclusão pendente: {ex}")
            falhas += 1
    
    # 1. Sincronizar diários pendentes
    cursor.execute("SELECT * FROM sf_local_diarios WHERE sincronizado = 0")
    diarios_pendentes = cursor.fetchall()
    
    DEBUG_SYNC = os.getenv("DEBUG_SYNC", "0") in ("1", "true", "True")
    for row in diarios_pendentes:
        try:
            # Prefer: resolution=merge-duplicates -> reenvio idempotente (não falha
            # se o registro já existir no Supabase; atualiza em vez de dar erro 409)
            res = _make_request("POST", "sf_eventos_diarios", body={
                "id": row["id"],
                "nome_evento": row["nome_evento"],
                "data_hora": row["data_hora"],
                "km_atual": row["km_atual"],
                "latitude": row["latitude"],
                "longitude": row["longitude"],
                "empresa_id": row["empresa_id"],
                "usuario_id": row["usuario_id"],
                "km_breadcrumbs": row["km_breadcrumbs"],
                "km_snap_road": row["km_snap_road"]
            }, headers={"Prefer": "resolution=merge-duplicates"})

            # Atualiza local para sincronizado
            cursor2 = conn.cursor()
            cursor2.execute("UPDATE sf_local_diarios SET sincronizado = 1 WHERE id = ?", (row["id"],))
            sincronizados += 1
            if DEBUG_SYNC:
                print(f"[DEBUG_SYNC] Posted diario {row['id']} -> response: {res}")
        except Exception as ex:
            print(f"Erro ao sincronizar diário pendente: {ex}")
            falhas += 1
            
    # 2. Sincronizar macros pendentes
    cursor.execute("SELECT * FROM sf_local_macros WHERE sincronizado = 0")
    macros_pendentes = cursor.fetchall()
    
    for row in macros_pendentes:
        try:
            res = _make_request("POST", "sf_eventos_macros", body={
                "id": row["id"],
                "evento_nome": row["evento_nome"],
                "data_hora": row["data_hora"],
                "km_atual": row["km_atual"],
                "litros": row["litros"],
                "valor_por_litro": row["valor_por_litro"],
                "descricao": row["descricao"],
                "valor_total": row["valor_total"],
                "empresa_id": row["empresa_id"],
                "usuario_id": row["usuario_id"]
            }, headers={"Prefer": "resolution=merge-duplicates"})

            # Atualiza local para sincronizado
            cursor2 = conn.cursor()
            cursor2.execute("UPDATE sf_local_macros SET sincronizado = 1 WHERE id = ?", (row["id"],))
            sincronizados += 1
            if DEBUG_SYNC:
                print(f"[DEBUG_SYNC] Posted macro {row['id']} -> response: {res}")
        except Exception as ex:
            print(f"Erro ao sincronizar macro pendente: {ex}")
            falhas += 1
            
    conn.commit()
    conn.close()
    _sync_fs_to_idb()
    return sincronizados, falhas

def get_empresas():
    if DIRECT_SUPABASE:
        try:
            return _make_request("GET", "sf_empresas")
        except Exception as e:
            print(f"Erro ao obter empresas do Supabase: {e}")
            return []
    # 1. Tenta ler do SQLite primeiro
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT id, nome, cnpj, sandbox FROM sf_local_empresas ORDER BY nome ASC")
        rows = cursor.fetchall()
        conn.close()
        if rows:
            return [dict(r) for r in rows]
    except Exception as e:
        print(f"Erro ao obter empresas do SQLite: {e}")

    # Fallback caso offline ou vazio
    return [
        {"id": "demo-empresa-1", "nome": "Empresa Demo SmartFrota", "cnpj": "12345678000199"},
        {"id": "e890f1ee-6c54-4b01-90e6-d701748f0852", "nome": "Transportes Estrela", "cnpj": "11111111000111"},
        {"id": "f890f1ee-6c54-4b01-90e6-d701748f0853", "nome": "Logística Global", "cnpj": "22222222000122"},
    ]

def get_usuarios():
    if DIRECT_SUPABASE:
        try:
            return _make_request("GET", "sf_usuarios")
        except Exception as e:
            print(f"Erro ao obter usuarios do Supabase: {e}")
            return []
    # 1. Tenta ler do SQLite primeiro
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT id, empresa_id, nome, email, role, senha FROM sf_local_usuarios ORDER BY nome ASC")
        rows = cursor.fetchall()
        conn.close()
        if rows:
            return [dict(r) for r in rows]
    except Exception as e:
        print(f"Erro ao obter usuários do SQLite: {e}")

    # Fallback caso offline ou vazio
    return [
        {"id": "demo-usuario-1", "empresa_id": "demo-empresa-1", "nome": "Motorista Demo", "email": "motorista@demo.com", "role": "motorista", "senha": "123456"},
        {"id": "c3c8f18c-39ff-43ea-96b6-7c1527efcf95", "empresa_id": "e890f1ee-6c54-4b01-90e6-d701748f0852", "nome": "Motorista João", "email": "joao@demo.com", "role": "motorista", "senha": "123456"},
        {"id": "d3c8f18c-39ff-43ea-96b6-7c1527efcf96", "empresa_id": "f890f1ee-6c54-4b01-90e6-d701748f0853", "nome": "Motorista Maria", "email": "maria@demo.com", "role": "motorista", "senha": "123456"},
    ]

# --- SINCronização LEVE DE CADASTROS (usada na tela de login) ---
def sincronizar_cadastros():
    """Baixa apenas os cadastros (empresas, usuários, configs, veículos) do Supabase
    e atualiza o SQLite local — sem baixar eventos. Rápida, usada antes do login
    para popular a lista de contas reais em vez do fallback de demonstração."""
    if not verificar_conexao():
        return False
    try:
        empresas = _make_request("GET", "sf_empresas")
        usuarios = _make_request("GET", "sf_usuarios", params=[("select", "id,empresa_id,nome,email,role,veiculo_id")])
        configs = _make_request("GET", "sf_configuracoes_eventos")
        veiculos = _make_request("GET", "sf_veiculos")
        usr_configs = _make_request("GET", "sf_usuario_configuracoes_eventos")

        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()

        if empresas:
            cursor.execute("DELETE FROM sf_local_empresas")
            for emp in empresas:
                sandbox = 1 if emp.get("sandbox") else 0
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_empresas (id, nome, cnpj, sandbox) VALUES (?, ?, ?, ?)",
                    (emp["id"], emp["nome"], emp.get("cnpj"), sandbox)
                )

        if usuarios:
            cursor.execute("DELETE FROM sf_local_usuarios")
            for usr in usuarios:
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_usuarios (id, empresa_id, nome, email, role, senha, veiculo_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (usr["id"], usr["empresa_id"], usr["nome"], usr["email"], usr["role"], usr.get("senha"), usr.get("veiculo_id"))
                )

        if configs:
            cursor.execute("DELETE FROM sf_local_configuracoes_eventos")
            for cfg in configs:
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_configuracoes_eventos (id, empresa_id, nome, tipo, visivel_motorista) VALUES (?, ?, ?, ?, ?)",
                    (cfg["id"], cfg.get("empresa_id"), cfg["nome"], cfg["tipo"], 1 if cfg.get("visivel_motorista", True) else 0)
                )

        if veiculos:
            cursor.execute("DELETE FROM sf_local_veiculos")
            for v in veiculos:
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_veiculos (id, empresa_id, placa, marca, modelo) VALUES (?, ?, ?, ?, ?)",
                    (v["id"], v["empresa_id"], v["placa"], v.get("marca"), v.get("modelo"))
                )

        if usr_configs:
            cursor.execute("DELETE FROM sf_local_usuario_configuracoes_eventos")
            for uc in usr_configs:
                part = 1 if uc.get("participa_sequencia", True) else 0
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_usuario_configuracoes_eventos (usuario_id, configuracao_evento_id, ordem_sequencia, participa_sequencia) VALUES (?, ?, ?, ?)",
                    (uc["usuario_id"], uc["configuracao_evento_id"], uc.get("ordem_sequencia", 0), part)
                )

        conn.commit()
        conn.close()
        _sync_fs_to_idb()
        return True
    except Exception as e:
        print(f"Erro ao sincronizar cadastros: {e}")
        return False


def autenticar_motorista(usuario_id: str, senha: str) -> bool:
    """Valida as credenciais do motorista via RPC do Supabase (não expõe a senha ao cliente)."""
    try:
        res = _make_request(
            "POST",
            "rpc/autenticar_motorista",
            body={"p_usuario_id": usuario_id, "p_senha": senha},
        )
        if isinstance(res, bool):
            return res
        if isinstance(res, list) and res:
            return bool(res[0])
        return False
    except Exception as e:
        print(f"Erro ao autenticar motorista: {e}")
        return False


# --- SUCATEAMENTO/ATUALIZAÇÃO DE CACHE DO SUPABASE ---
def atualizar_cache_local(usuario_id: str = None):
    """Baixa os dados cadastrais e de configuração do Supabase e atualiza o SQLite local"""
    if not verificar_conexao():
        return False
    try:
        empresas = _make_request("GET", "sf_empresas")
        usuarios = _make_request("GET", "sf_usuarios", params=[("select", "id,empresa_id,nome,email,role,veiculo_id")])
        configs = _make_request("GET", "sf_configuracoes_eventos")
        veiculos = _make_request("GET", "sf_veiculos")
        usr_configs = _make_request("GET", "sf_usuario_configuracoes_eventos")
        
        if usuario_id:
            db_diarios = _make_request("GET", "sf_eventos_diarios", params=[("usuario_id", f"eq.{usuario_id}")])
            db_macros = _make_request("GET", "sf_eventos_macros", params=[("usuario_id", f"eq.{usuario_id}")])
        else:
            db_diarios = _make_request("GET", "sf_eventos_diarios")
            db_macros = _make_request("GET", "sf_eventos_macros")
        
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        
        # Atualizar empresas
        if empresas:
            cursor.execute("DELETE FROM sf_local_empresas")
            for emp in empresas:
                sandbox = 1 if emp.get("sandbox") else 0
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_empresas (id, nome, cnpj, sandbox) VALUES (?, ?, ?, ?)",
                    (emp["id"], emp["nome"], emp.get("cnpj"), sandbox)
                )
            # Sincroniza as flags sandbox vindas do Supabase para a tabela local de sandbox
            try:
                cursor.execute("DELETE FROM sf_local_sandbox")
                for emp in empresas:
                    if emp.get("sandbox"):
                        cursor.execute("INSERT OR REPLACE INTO sf_local_sandbox (empresa_id) VALUES (?)", (emp["id"],))
            except Exception as e:
                print(f"Erro ao sincronizar flags sandbox: {e}")
                
        # Atualizar usuários
        if usuarios:
            cursor.execute("DELETE FROM sf_local_usuarios")
            for usr in usuarios:
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_usuarios (id, empresa_id, nome, email, role, senha, veiculo_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (usr["id"], usr["empresa_id"], usr["nome"], usr["email"], usr["role"], usr.get("senha"), usr.get("veiculo_id"))
                )
                
        # Atualizar configurações de eventos
        if configs:
            cursor.execute("DELETE FROM sf_local_configuracoes_eventos")
            for cfg in configs:
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_configuracoes_eventos (id, empresa_id, nome, tipo, visivel_motorista) VALUES (?, ?, ?, ?, ?)",
                    (cfg["id"], cfg.get("empresa_id"), cfg["nome"], cfg["tipo"], 1 if cfg.get("visivel_motorista", True) else 0)
                )

        # Atualizar veículos
        if veiculos:
            cursor.execute("DELETE FROM sf_local_veiculos")
            for v in veiculos:
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_veiculos (id, empresa_id, placa, marca, modelo) VALUES (?, ?, ?, ?, ?)",
                    (v["id"], v["empresa_id"], v["placa"], v.get("marca"), v.get("modelo"))
                )

        # Atualizar configurações de eventos por motorista
        if usr_configs:
            cursor.execute("DELETE FROM sf_local_usuario_configuracoes_eventos")
            for uc in usr_configs:
                part = 1 if uc.get("participa_sequencia", True) else 0
                cursor.execute(
                    "INSERT OR REPLACE INTO sf_local_usuario_configuracoes_eventos (usuario_id, configuracao_evento_id, ordem_sequencia, participa_sequencia) VALUES (?, ?, ?, ?)",
                    (uc["usuario_id"], uc["configuracao_evento_id"], uc.get("ordem_sequencia", 0), part)
                )

        # IDs pendentes de exclusão (não devem ser restaurados pelo cache)
        cursor.execute("SELECT id FROM sf_local_exclusoes_pendentes")
        pending_deleted = set(r[0] for r in cursor.fetchall())

        # Atualizar diários vindos do Supabase
        # Remove registros já sincronizados do usuário e re-insere os atualizados
        # vindos do Supabase. Assim, registros apagados no backoffice somem do app.
        if usuario_id:
            cursor.execute("DELETE FROM sf_local_diarios WHERE sincronizado = 1 AND usuario_id = ?", (usuario_id,))
        else:
            cursor.execute("DELETE FROM sf_local_diarios WHERE sincronizado = 1")
        if db_diarios:
            for d in db_diarios:
                if d["id"] in pending_deleted:
                    continue
                cursor.execute(
                    """INSERT OR REPLACE INTO sf_local_diarios 
                    (id, nome_evento, data_hora, km_atual, latitude, longitude, empresa_id, usuario_id, sincronizado, km_breadcrumbs, km_snap_road) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)""",
                    (d["id"], d["nome_evento"], d["data_hora"], d["km_atual"], d.get("latitude"), d.get("longitude"), d.get("empresa_id"), d.get("usuario_id"), d.get("km_breadcrumbs"), d.get("km_snap_road"))
                )

        # Atualizar macros vindos do Supabase
        # Remove registros já sincronizados do usuário e re-insere a lista atualizada
        # vinda do Supabase.
        if usuario_id:
            cursor.execute("DELETE FROM sf_local_macros WHERE sincronizado = 1 AND usuario_id = ?", (usuario_id,))
        else:
            cursor.execute("DELETE FROM sf_local_macros WHERE sincronizado = 1")
        if db_macros:
            for m in db_macros:
                if m["id"] in pending_deleted:
                    continue
                cursor.execute(
                    """INSERT OR REPLACE INTO sf_local_macros 
                    (id, evento_nome, data_hora, km_atual, litros, valor_por_litro, descricao, valor_total, empresa_id, usuario_id, sincronizado) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)""",
                    (m["id"], m["evento_nome"], m["data_hora"], m.get("km_atual"), m.get("litros"), m.get("valor_por_litro"), m.get("descricao"), m.get("valor_total"), m.get("empresa_id"), m.get("usuario_id"))
                )
                
        conn.commit()
        conn.close()
        # Recarrega o set em memória com as flags sandbox recém-sincronizadas
        _load_sandbox_empresa_ids_from_db()
        _sync_fs_to_idb()
        print("Cache local SQLite atualizado com sucesso do Supabase.")
        return True
    except Exception as e:
        print(f"Erro ao atualizar cache local SQLite: {e}")
        return False

def get_driver_veiculo(usuario_id: str):
    if DIRECT_SUPABASE:
        try:
            usr = _make_request("GET", "sf_usuarios", params=[("id", f"eq.{usuario_id}")])
            if usr and usr[0].get("veiculo_id"):
                veh = _make_request("GET", "sf_veiculos", params=[("id", f"eq.{usr[0]['veiculo_id']}")])
                if veh:
                    return veh[0]
        except Exception as e:
            print(f"Erro ao obter veiculo do motorista no Supabase: {e}")
        return None
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("""
            SELECT v.id, v.placa, v.marca, v.modelo 
            FROM sf_local_veiculos v
            JOIN sf_local_usuarios u ON u.veiculo_id = v.id
            WHERE u.id = ?
        """, (usuario_id,))
        row = cursor.fetchone()
        conn.close()
        if row:
            return dict(row)
    except Exception as e:
        print(f"Erro ao obter veiculo do motorista: {e}")
    return None

def get_usuario_event_configs(usuario_id: str, tipo: str = None):
    if DIRECT_SUPABASE:
        try:
            uc_list = _make_request("GET", "sf_usuario_configuracoes_eventos", params=[("usuario_id", f"eq.{usuario_id}")])
            all_c = _make_request("GET", "sf_configuracoes_eventos")
            c_map = {c["id"]: c for c in all_c}
            res = []
            for uc in uc_list:
                cfg_id = uc["configuracao_evento_id"]
                if cfg_id in c_map:
                    c = c_map[cfg_id]
                    if not tipo or c["tipo"] == tipo:
                        res.append({
                            "id": c["id"],
                            "nome": c["nome"],
                            "tipo": c["tipo"],
                            "visivel_motorista": 1 if c.get("visivel_motorista", True) else 0,
                            "ordem_sequencia": uc.get("ordem_sequencia", 0),
                            "participa_sequencia": 1 if uc.get("participa_sequencia", True) else 0
                        })
            res.sort(key=lambda x: (x["ordem_sequencia"], x["nome"]))
            return res
        except Exception as e:
            print(f"Erro ao obter configuracoes de eventos no Supabase diretamente: {e}")
            return []
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        if tipo:
            cursor.execute("""
                SELECT c.id, c.nome, c.tipo, c.visivel_motorista, uc.ordem_sequencia, uc.participa_sequencia
                FROM sf_local_configuracoes_eventos c
                JOIN sf_local_usuario_configuracoes_eventos uc ON uc.configuracao_evento_id = c.id
                WHERE uc.usuario_id = ? AND c.tipo = ?
                ORDER BY uc.ordem_sequencia ASC, c.nome ASC
            """, (usuario_id, tipo))
        else:
            cursor.execute("""
                SELECT c.id, c.nome, c.tipo, c.visivel_motorista, uc.ordem_sequencia, uc.participa_sequencia
                FROM sf_local_configuracoes_eventos c
                JOIN sf_local_usuario_configuracoes_eventos uc ON uc.configuracao_evento_id = c.id
                WHERE uc.usuario_id = ?
                ORDER BY uc.ordem_sequencia ASC, c.nome ASC
            """, (usuario_id,))
            
        rows = cursor.fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception as e:
        print(f"Erro ao obter configuracoes de eventos do motorista: {e}")
    return []

def add_usuario(nome: str, email: str, role: str, senha: str, empresa_id: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                import uuid
                user_id = str(uuid.uuid4())
                return _make_request("POST", "sf_usuarios", body={
                    "id": user_id,
                    "nome": nome,
                    "email": email,
                    "role": role,
                    "senha": senha,
                    "empresa_id": empresa_id
                })
            except Exception as e:
                print(f"Erro ao inserir usuário no Supabase: {e}")
                raise e
        else:
            raise Exception("Sem conexão com a internet para criar usuário.")
    # Primeiro insere localmente
    import uuid
    user_id = str(uuid.uuid4())
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO sf_local_usuarios (id, empresa_id, nome, email, role, senha) VALUES (?, ?, ?, ?, ?, ?)",
            (user_id, empresa_id, nome, email, role, senha)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Erro ao inserir usuário localmente: {e}")

    if verificar_conexao():
        try:
            return _make_request("POST", "sf_usuarios", body={
                "id": user_id,
                "nome": nome,
                "email": email,
                "role": role,
                "senha": senha,
                "empresa_id": empresa_id
            })
        except Exception as e:
            print(f"Erro ao inserir usuário no Supabase: {e}")
            raise e
    else:
        raise Exception("Sem conexão com a internet para criar usuário.")

def delete_daily_event(event_id: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                _make_request("DELETE", "sf_eventos_diarios", params=[("id", f"eq.{event_id}")])
            except Exception as e:
                print(f"Erro ao deletar evento diário no Supabase: {e}")
        return

    # 1. Verifica se o registro já estava sincronizado ou pendente
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT sincronizado FROM sf_local_diarios WHERE id = ?", (event_id,))
    row = cursor.fetchone()
    was_synced = row[0] if row else 1

    # 2. Deleta localmente do SQLite
    cursor.execute("DELETE FROM sf_local_diarios WHERE id = ?", (event_id,))

    # 3. Se já estava no Supabase (sincronizado == 1), anota na fila de exclusões pendentes
    if was_synced != 0:
        cursor.execute(
            "INSERT OR REPLACE INTO sf_local_exclusoes_pendentes (id, tabela, data_hora) VALUES (?, ?, ?)",
            (event_id, "sf_eventos_diarios", datetime.now(timezone.utc).isoformat())
        )
    conn.commit()
    conn.close()
    _sync_fs_to_idb()

    # 4. Se estiver online, tenta deletar imediatamente no Supabase
    if was_synced != 0 and verificar_conexao():
        try:
            _make_request("DELETE", "sf_eventos_diarios", params=[("id", f"eq.{event_id}")])
            conn = sqlite3.connect(SQLITE_PATH)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM sf_local_exclusoes_pendentes WHERE id = ?", (event_id,))
            conn.commit()
            conn.close()
            _sync_fs_to_idb()
        except Exception as e:
            print(f"Erro ao deletar evento diário no Supabase (ficou na fila offline): {e}")

def update_daily_event(event_id: str, nome_evento: str, km_atual: float, latitude: float, longitude: float, data_hora: str, usuario_id: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                _make_request("PATCH", "sf_eventos_diarios", params=[("id", f"eq.{event_id}")], body={
                    "nome_evento": nome_evento,
                    "km_atual": km_atual,
                    "latitude": latitude,
                    "longitude": longitude,
                    "data_hora": data_hora,
                    "usuario_id": usuario_id
                })
            except Exception as e:
                print(f"Erro ao atualizar evento diário no Supabase: {e}")
        return
    # 1. Update locally
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE sf_local_diarios SET nome_evento = ?, km_atual = ?, latitude = ?, longitude = ?, data_hora = ?, usuario_id = ?, sincronizado = 0 WHERE id = ?",
        (nome_evento, km_atual, latitude, longitude, data_hora, usuario_id, event_id)
    )
    conn.commit()
    conn.close()

    # 2. If online, update Supabase
    if verificar_conexao():
        try:
            _make_request("PATCH", "sf_eventos_diarios", params=[("id", f"eq.{event_id}")], body={
                "nome_evento": nome_evento,
                "km_atual": km_atual,
                "latitude": latitude,
                "longitude": longitude,
                "data_hora": data_hora,
                "usuario_id": usuario_id
            })
            # Mark as synced
            conn = sqlite3.connect(SQLITE_PATH)
            cursor = conn.cursor()
            cursor.execute("UPDATE sf_local_diarios SET sincronizado = 1 WHERE id = ?", (event_id,))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Erro ao atualizar evento diário no Supabase: {e}")

def delete_macro_event(event_id: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                _make_request("DELETE", "sf_eventos_macros", params=[("id", f"eq.{event_id}")])
            except Exception as e:
                print(f"Erro ao deletar evento macro no Supabase: {e}")
        return

    # 1. Verifica se o registro já estava sincronizado ou pendente
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT sincronizado FROM sf_local_macros WHERE id = ?", (event_id,))
    row = cursor.fetchone()
    was_synced = row[0] if row else 1

    # 2. Deleta localmente do SQLite
    cursor.execute("DELETE FROM sf_local_macros WHERE id = ?", (event_id,))

    # 3. Se já estava no Supabase (sincronizado == 1), anota na fila de exclusões pendentes
    if was_synced != 0:
        cursor.execute(
            "INSERT OR REPLACE INTO sf_local_exclusoes_pendentes (id, tabela, data_hora) VALUES (?, ?, ?)",
            (event_id, "sf_eventos_macros", datetime.now(timezone.utc).isoformat())
        )
    conn.commit()
    conn.close()
    _sync_fs_to_idb()

    # 4. Se estiver online, tenta deletar imediatamente no Supabase
    if was_synced != 0 and verificar_conexao():
        try:
            _make_request("DELETE", "sf_eventos_macros", params=[("id", f"eq.{event_id}")])
            conn = sqlite3.connect(SQLITE_PATH)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM sf_local_exclusoes_pendentes WHERE id = ?", (event_id,))
            conn.commit()
            conn.close()
            _sync_fs_to_idb()
        except Exception as e:
            print(f"Erro ao deletar evento macro no Supabase (ficou na fila offline): {e}")

def update_macro_event(event_id: str, evento_nome: str, km_atual: float, litros: float, valor_por_litro: float, descricao: str, valor_total: float, data_hora: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                _make_request("PATCH", "sf_eventos_macros", params=[("id", f"eq.{event_id}")], body={
                    "evento_nome": evento_nome,
                    "km_atual": km_atual,
                    "litros": litros,
                    "valor_por_litro": valor_por_litro,
                    "descricao": descricao,
                    "valor_total": valor_total,
                    "data_hora": data_hora
                })
            except Exception as e:
                print(f"Erro ao atualizar evento macro no Supabase: {e}")
        return
    # 1. Update locally
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE sf_local_macros SET evento_nome = ?, km_atual = ?, litros = ?, valor_por_litro = ?, descricao = ?, valor_total = ?, data_hora = ?, sincronizado = 0 WHERE id = ?",
        (evento_nome, km_atual, litros, valor_por_litro, descricao, valor_total, data_hora, event_id)
    )
    conn.commit()
    conn.close()

    # 2. If online, update Supabase
    if verificar_conexao():
        try:
            _make_request("PATCH", "sf_eventos_macros", params=[("id", f"eq.{event_id}")], body={
                "evento_nome": evento_nome,
                "km_atual": km_atual,
                "litros": litros,
                "valor_por_litro": valor_por_litro,
                "descricao": descricao,
                "valor_total": valor_total,
                "data_hora": data_hora
            })
            # Mark as synced
            conn = sqlite3.connect(SQLITE_PATH)
            cursor = conn.cursor()
            cursor.execute("UPDATE sf_local_macros SET sincronizado = 1 WHERE id = ?", (event_id,))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Erro ao atualizar evento macro no Supabase: {e}")

def get_osrm_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    if lat1 is None or lon1 is None or lat2 is None or lon2 is None:
        return 0.0
    try:
        url = f"https://router.project-osrm.org/route/v1/driving/{lon1},{lat1};{lon2},{lat2}?overview=false"
        req = urllib.request.Request(url, headers={"User-Agent": "SmartFrota/1.0"})
        with urllib.request.urlopen(req, timeout=3.0) as response:
            data = json.loads(response.read().decode("utf-8"))
            if data.get("code") == "Ok" and "routes" in data:
                return float(data["routes"][0]["distance"]) / 1000.0
    except Exception as e:
        print(f"Erro ao calcular rota OSRM: {e}")
    return 0.0

def get_veiculos(empresa_id: str):
    if DIRECT_SUPABASE:
        try:
            return _make_request("GET", "sf_veiculos", params=[("empresa_id", f"eq.{empresa_id}"), ("order", "placa.asc")])
        except Exception as e:
            print(f"Erro ao obter veiculos do Supabase diretamente: {e}")
            return []
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT id, empresa_id, placa, marca, modelo FROM sf_local_veiculos WHERE empresa_id = ? ORDER BY placa ASC", (empresa_id,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception as e:
        print(f"Erro ao obter veiculos locais: {e}")
    return []

def add_veiculo(placa: str, marca: str, modelo: str, empresa_id: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                import uuid
                veh_id = str(uuid.uuid4())
                _make_request("POST", "sf_veiculos", body={
                    "id": veh_id,
                    "empresa_id": empresa_id,
                    "placa": placa,
                    "marca": marca,
                    "modelo": modelo
                })
                return veh_id
            except Exception as e:
                print(f"Erro ao inserir veiculo no Supabase: {e}")
                raise e
        return None
    import uuid
    veh_id = str(uuid.uuid4())
    try:
        conn = sqlite3.connect(SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO sf_local_veiculos (id, empresa_id, placa, marca, modelo) VALUES (?, ?, ?, ?, ?)",
            (veh_id, empresa_id, placa, marca, modelo)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Erro ao inserir veiculo localmente: {e}")
        
    if verificar_conexao():
        try:
            _make_request("POST", "sf_veiculos", body={
                "id": veh_id,
                "empresa_id": empresa_id,
                "placa": placa,
                "marca": marca,
                "modelo": modelo
            })
            return veh_id
        except Exception as e:
            print(f"Erro ao inserir veiculo no Supabase: {e}")
            raise e

def delete_veiculo(veh_id: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                _make_request("DELETE", "sf_veiculos", params=[("id", f"eq.{veh_id}")])
            except Exception as e:
                print(f"Erro ao deletar veiculo no Supabase: {e}")
        return
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM sf_local_veiculos WHERE id = ?", (veh_id,))
    conn.commit()
    conn.close()
    if verificar_conexao():
        try:
            _make_request("DELETE", "sf_veiculos", params=[("id", f"eq.{veh_id}")])
        except Exception as e:
            print(f"Erro ao deletar veiculo no Supabase: {e}")

def update_usuario_veiculo(usuario_id: str, veiculo_id: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                _make_request("PATCH", "sf_usuarios", params=[("id", f"eq.{usuario_id}")], body={"veiculo_id": veiculo_id})
            except Exception as e:
                print(f"Erro ao associar veiculo no Supabase: {e}")
        return
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute("UPDATE sf_local_usuarios SET veiculo_id = ? WHERE id = ?", (veiculo_id, usuario_id))
    conn.commit()
    conn.close()
    if verificar_conexao():
        try:
            _make_request("PATCH", "sf_usuarios", params=[("id", f"eq.{usuario_id}")], body={"veiculo_id": veiculo_id})
        except Exception as e:
            print(f"Erro ao associar veiculo no Supabase: {e}")

def assign_evento_to_usuario(usuario_id: str, config_id: str, ordem: int, participa: bool = True):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                existing = _make_request("GET", "sf_usuario_configuracoes_eventos", params=[
                    ("usuario_id", f"eq.{usuario_id}"),
                    ("configuracao_evento_id", f"eq.{config_id}")
                ])
                if existing:
                    _make_request("PATCH", "sf_usuario_configuracoes_eventos", params=[
                        ("usuario_id", f"eq.{usuario_id}"),
                        ("configuracao_evento_id", f"eq.{config_id}")
                    ], body={"ordem_sequencia": ordem, "participa_sequencia": participa})
                else:
                    _make_request("POST", "sf_usuario_configuracoes_eventos", body={
                        "usuario_id": usuario_id,
                        "configuracao_evento_id": config_id,
                        "ordem_sequencia": ordem,
                        "participa_sequencia": participa
                    })
            except Exception as e:
                print(f"Erro ao salvar atribuicao no Supabase: {e}")
        return
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO sf_local_usuario_configuracoes_eventos (usuario_id, configuracao_evento_id, ordem_sequencia, participa_sequencia)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(usuario_id, configuracao_evento_id) DO UPDATE SET ordem_sequencia = EXCLUDED.ordem_sequencia, participa_sequencia = EXCLUDED.participa_sequencia
    """, (usuario_id, config_id, ordem, 1 if participa else 0))
    conn.commit()
    conn.close()
    if verificar_conexao():
        try:
            # Verifica primeiro se já existe para evitar o conflito de chave única (409)
            existing = _make_request("GET", "sf_usuario_configuracoes_eventos", params=[
                ("usuario_id", f"eq.{usuario_id}"),
                ("configuracao_evento_id", f"eq.{config_id}")
            ])
            if existing:
                _make_request("PATCH", "sf_usuario_configuracoes_eventos", params=[
                    ("usuario_id", f"eq.{usuario_id}"),
                    ("configuracao_evento_id", f"eq.{config_id}")
                ], body={"ordem_sequencia": ordem, "participa_sequencia": participa})
            else:
                _make_request("POST", "sf_usuario_configuracoes_eventos", body={
                    "usuario_id": usuario_id,
                    "configuracao_evento_id": config_id,
                    "ordem_sequencia": ordem,
                    "participa_sequencia": participa
                })
        except Exception as e:
            print(f"Erro ao salvar atribuicao no Supabase: {e}")

def remove_evento_from_usuario(usuario_id: str, config_id: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                _make_request("DELETE", "sf_usuario_configuracoes_eventos", params=[
                    ("usuario_id", f"eq.{usuario_id}"),
                    ("configuracao_evento_id", f"eq.{config_id}")
                ])
            except Exception as e:
                print(f"Erro ao deletar configuracao no Supabase: {e}")
        return
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM sf_local_usuario_configuracoes_eventos WHERE usuario_id = ? AND configuracao_evento_id = ?", (usuario_id, config_id))
    conn.commit()
    conn.close()
    if verificar_conexao():
        try:
            _make_request("DELETE", "sf_usuario_configuracoes_eventos", params=[
                ("usuario_id", f"eq.{usuario_id}"),
                ("configuracao_evento_id", f"eq.{config_id}")
            ])
        except Exception as e:
            print(f"Erro ao deletar configuracao no Supabase: {e}")

def update_veiculo(veh_id: str, placa: str, marca: str, modelo: str):
    if DIRECT_SUPABASE:
        if verificar_conexao():
            try:
                _make_request("PATCH", "sf_veiculos", params=[("id", f"eq.{veh_id}")], body={
                    "placa": placa,
                    "marca": marca,
                    "modelo": modelo
                })
            except Exception as e:
                print(f"Erro ao atualizar veiculo no Supabase: {e}")
        return
    conn = sqlite3.connect(SQLITE_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE sf_local_veiculos SET placa = ?, marca = ?, modelo = ? WHERE id = ?",
        (placa, marca, modelo, veh_id)
    )
    conn.commit()
    conn.close()
    if verificar_conexao():
        try:
            _make_request("PATCH", "sf_veiculos", params=[("id", f"eq.{veh_id}")], body={
                "placa": placa,
                "marca": marca,
                "modelo": modelo
            })
        except Exception as e:
            print(f"Erro ao atualizar veiculo no Supabase: {e}")



