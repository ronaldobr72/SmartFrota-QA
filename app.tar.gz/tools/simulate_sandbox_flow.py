import os, sys
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
import database as db
import sqlite3
import uuid

DB = db.SQLITE_PATH

# Setup: ensure sandbox flag
sandbox_eid = 'sandbox-flow-1'
db.set_sandbox_empresa_ids([sandbox_eid])
print('SANDBOX IDs now:', db.SANDBOX_EMPRESA_IDS)

# Ensure offline mode
db.set_force_offline(True)
print('FORCE_OFFLINE:', db.FORCE_OFFLINE)

# Create 3 local events (offline)
ids = []
for i in range(3):
    res = db.register_daily_event(nome_evento=f'TEST-SB-{i+1}', km_atual=100+i, empresa_id=sandbox_eid, usuario_id='u-test')
    ids.append(res['id'])
print('Inserted event ids:', ids)

# Check local DB counts (should be 3 unsynced)
conn = sqlite3.connect(DB)
c = conn.cursor()
c.execute("SELECT COUNT(*) FROM sf_local_diarios WHERE empresa_id = ? AND sincronizado = 0", (sandbox_eid,))
print('unsynced count (should be 3):', c.fetchone()[0])
conn.close()

# Go online
db.set_force_offline(False)
print('FORCE_OFFLINE after:', db.FORCE_OFFLINE)

# Run sync (should mark events as synced but NOT post to Supabase)
synced, failed = db.sincronizar_dados_pendentes()
print('sincronizar_dados_pendentes ->', synced, 'synced,', failed, 'failures')

# Check local DB counts after sync (should be 3 synced)
conn = sqlite3.connect(DB)
c = conn.cursor()
c.execute("SELECT COUNT(*) FROM sf_local_diarios WHERE empresa_id = ? AND sincronizado = 1", (sandbox_eid,))
print('synced count (should be 3):', c.fetchone()[0])

# Simulate atualizar_cache_local cleanup delete (same SQL used in atualizar_cache_local)
c.execute("""
DELETE FROM sf_local_diarios
WHERE sincronizado = 1
AND (empresa_id IS NULL OR empresa_id NOT IN (SELECT empresa_id FROM sf_local_sandbox))
""")
conn.commit()

# Check remaining rows (sandbox should remain)
c.execute("SELECT COUNT(*) FROM sf_local_diarios WHERE empresa_id = ?", (sandbox_eid,))
print('remaining sandbox rows after cleanup (should be 3):', c.fetchone()[0])

# Cleanup inserted rows and sandbox flag
c.execute("DELETE FROM sf_local_diarios WHERE empresa_id = ?", (sandbox_eid,))
c.execute("DELETE FROM sf_local_sandbox WHERE empresa_id = ?", (sandbox_eid,))
conn.commit()
conn.close()
print('Cleanup done')
