import os, sys, urllib.request, json
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from database import SUPABASE_URL, SUPABASE_KEY

url = f"{SUPABASE_URL}/rest/v1/sf_eventos_diarios"
body = {
    "id": "debug-uuid-1234",
    "nome_evento": "Teste Debug",
    "data_hora": "2026-08-13T14:00:00+00:00",
    "km_atual": 123.4,
    "latitude": -23.6,
    "longitude": -46.6,
    "empresa_id": "demo-empresa-1",
    "usuario_id": "demo-usuario-1",
    "km_breadcrumbs": 0.0,
    "km_snap_road": 0.0
}
req = urllib.request.Request(url, data=json.dumps(body).encode('utf-8'), headers={"apikey": SUPABASE_KEY, "Authorization": f"Bearer {SUPABASE_KEY}", "Content-Type": "application/json"}, method='POST')
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        print('Status', resp.status)
        print('Response:', resp.read().decode())
except Exception as e:
    try:
        import urllib.error
        if isinstance(e, urllib.error.HTTPError):
            print('HTTPError code:', e.code)
            try:
                print('Error body:', e.read().decode())
            except Exception as ex:
                print('Could not read body:', ex)
        else:
            print('Error:', e)
    except Exception:
        print('Error generic:', e)
