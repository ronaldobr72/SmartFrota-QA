@echo off
echo =======================================================
echo        SmartFrota - Auto Deploy PWA (PRODUCAO)
echo =======================================================
echo.

echo 1. Compilando o aplicativo Flet para Web (Producao)...
"C:\Users\ronrosa\AppData\Roaming\Python\Python313\Scripts\flet.exe" publish main_mobile.py --base-url /SmartFrota-PRD/
if %ERRORLEVEL% NEQ 0 (
    echo [ERRO] Falha ao compilar o aplicativo.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo 2. Aplicando Patch de Versao e Branding Producao...
py patch_worker.py --env prod
if %ERRORLEVEL% NEQ 0 (
    echo [ERRO] Falha ao aplicar o patch.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo 2.1 Gerando Icones de Producao (Azul)...
py generate_icons.py --env prod
if %ERRORLEVEL% NEQ 0 (
    echo [ERRO] Falha ao gerar icones de producao.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo 3. Entrando na pasta dist...
cd dist

echo.
echo 4. Inicializando o repositório Git temporário...
git init
git remote add origin https://github.com/ronaldobr72/SmartFrota-PRD.git
git branch -M main

echo.
echo 5. Adicionando arquivos e commitando...
git add .
git commit -m "Deploy Flet PWA App - Producao Build"

echo.
echo 6. Enviando para o GitHub Pages (Forçado)...
git push -u origin main --force

echo.
echo =======================================================
echo       Deploy Concluído! O app estará online em breve:
echo       https://ronaldobr72.github.io/SmartFrota-PRD/
echo =======================================================
pause
