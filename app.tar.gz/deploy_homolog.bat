@echo off
echo =======================================================
echo        SmartFrota - Auto Deploy PWA (HOMOLOG)
echo =======================================================
echo.

echo 1. Limpando cache e compilando aplicativo para Homolog...
"C:\Users\ronrosa\AppData\Roaming\Python\Python313\Scripts\flet.exe" publish main_mobile.py --base-url /SmartFrota-QA/
if %ERRORLEVEL% NEQ 0 (
    echo [ERRO] Falha ao compilar o aplicativo.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo 2. Aplicando Patch de Versao e Branding Homolog...
py patch_worker.py --env homolog
if %ERRORLEVEL% NEQ 0 (
    echo [ERRO] Falha ao aplicar o patch.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo 2.1 Gerando Icones de Homologacao (Laranja)...
py generate_icons.py --env homolog
if %ERRORLEVEL% NEQ 0 (
    echo [ERRO] Falha ao gerar icones de homologacao.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo 3. Entrando na pasta dist...
cd dist

echo.
echo 4. Inicializando o repositório Git temporário de Homolog...
git init
git remote add origin https://github.com/ronaldobr72/SmartFrota-QA.git
git branch -M main

echo.
echo 5. Adicionando arquivos e commitando...
git add .
git commit -m "Deploy Flet PWA App - Homolog Build"

echo.
echo 6. Enviando para o GitHub Pages (Forçado)...
git push -u origin main --force

echo.
echo =======================================================
echo    Deploy Concluído! O app de testes estará online em:
echo    https://ronaldobr72.github.io/SmartFrota-QA/
echo =======================================================
pause
