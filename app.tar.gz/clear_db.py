import sqlite3
import database as db

def clear_sqlite():
    print("Limpando banco de dados local SQLite...")
    try:
        conn = sqlite3.connect(db.SQLITE_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM sf_local_diarios")
        cursor.execute("DELETE FROM sf_local_macros")
        conn.commit()
        conn.close()
        print("SQLite limpo com sucesso!")
    except Exception as e:
        print(f"Erro ao limpar SQLite: {e}")

def clear_supabase():
    print("Limpando tabelas do Supabase...")
    if not db.verificar_conexao():
        print("Erro: Sem conexão com a internet para limpar o Supabase.")
        return
    
    try:
        client = db.get_supabase_client()
        
        # 1. Limpar tabelas operacionais
        print("Limpando sf_eventos_diarios...")
        client.table("sf_eventos_diarios").delete().neq("id", "00000000-0000-0000-0000-000000000000").execute()
        
        print("Limpando sf_eventos_macros...")
        client.table("sf_eventos_macros").delete().neq("id", "00000000-0000-0000-0000-000000000000").execute()
        
        print("Limpando sf_configuracoes_eventos...")
        client.table("sf_configuracoes_eventos").delete().neq("id", "00000000-0000-0000-0000-000000000000").execute()
        
        print("Limpando sf_usuarios...")
        client.table("sf_usuarios").delete().neq("id", "00000000-0000-0000-0000-000000000000").execute()
        
        print("Limpando sf_empresas...")
        client.table("sf_empresas").delete().neq("id", "00000000-0000-0000-0000-000000000000").execute()

        print("Recriando dados de Seed iniciais...")
        # 2. Inserir dados básicos de seed novamente para a Empresa Demo
        empresa_id = "demo-empresa-1"
        usuario_id = "demo-usuario-1"
        
        client.table("sf_empresas").insert({"id": empresa_id, "nome": "Empresa Demo SmartFrota", "cnpj": "12345678000199"}).execute()
        client.table("sf_usuarios").insert({
            "id": usuario_id,
            "empresa_id": empresa_id,
            "nome": "Motorista Demo",
            "email": "motorista@demo.com",
            "role": "motorista"
        }).execute()
        
        # Configurações padrões
        client.table("sf_configuracoes_eventos").insert([
            {"empresa_id": empresa_id, "nome": "Abastecimento", "tipo": "macro", "visivel_motorista": True},
            {"empresa_id": empresa_id, "nome": "Manutenções", "tipo": "macro", "visivel_motorista": True},
            {"empresa_id": empresa_id, "nome": "Aluguel da garagem", "tipo": "macro", "visivel_motorista": False},
            {"empresa_id": empresa_id, "nome": "Outros", "tipo": "macro", "visivel_motorista": True}
        ]).execute()
        
        print("Supabase limpo e re-populado com dados básicos com sucesso!")
    except Exception as e:
        print(f"Erro ao limpar Supabase: {e}")

if __name__ == "__main__":
    clear_sqlite()
    clear_supabase()
